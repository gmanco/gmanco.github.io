/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package core.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class IOManager {

	public static Object loadObjectFromFile(String fileName) throws Exception {
		ObjectInputStream in = null;
		Object o = null;
		try {
			in = new ObjectInputStream(new GZIPInputStream(new FileInputStream(
					new File(fileName))));
			o = in.readObject();
			in.close();
			return o;
		} catch (Exception ex) {
			try {
				ex.printStackTrace();
				in.close();
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
			throw ex;
		}
	}

	public static void writeObjectOnFile(Serializable s, String fileName)
			throws Exception {
		ObjectOutputStream out = null;
		try {
			GZIPOutputStream gz = new GZIPOutputStream(new FileOutputStream(
					new File(fileName)));
			out = new ObjectOutputStream(gz);
			out.writeObject(s);
			out.flush();
			gz.flush();
			gz.finish();
			out.close();
		} catch (Exception ex) {
			try {
				ex.printStackTrace();
				out.close();
			} catch (Exception ex2) {
				ex2.printStackTrace();
			}
			throw ex;
		}
	}
}