/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package core.util;

import java.util.LinkedList;

public class ArrayUtilities {

	public static double SMALL = 1e-6;

	/**
	 * 
	 * @param a
	 *            first array
	 * @param b
	 *            second array
	 * @param threshold
	 * @return true if |a - b|/|a| < threshold false otherwise
	 */
	public static boolean arrayConverged(double a[], double b[],
			double threshold) {

		double a2sum = 0;
		double difference2 = 0;

		for (int i = 0; i < a.length; i++) {
			a2sum += a[i] * a[i];
			difference2 += (a[i] - b[i]) * (a[i] - b[i]);
		}
		/**
		 * sqrt ( (a-b)^2/a^2 )< threshold
		 */
		// System.out.println("A2sum::: "+a2sum);
		if (Math.sqrt(difference2 / a2sum) < threshold)
			return true;
		else
			return false;
	}// arrayConverged

	public static boolean arrayConverged(float a[], float b[], double threshold) {

		double a2sum = 0;
		double difference2 = 0;

		for (int i = 0; i < a.length; i++) {
			a2sum += a[i] * a[i];
			difference2 += (a[i] - b[i]) * (a[i] - b[i]);
		}
		/**
		 * sqrt ( (a-b)^2/a^2 )< threshold
		 */
		// System.out.println("A2sum::: "+a2sum);
		if (Math.sqrt(difference2 / a2sum) < threshold)
			return true;
		else
			return false;
	}// arrayConverged

	public static String arrayToString(double m[]) {
		StringBuffer sb = new StringBuffer();
		for (double element : m)
			sb.append("" + element + "\t");
		return sb.toString();
	}

	// swaps array elements i and j
	public static void exch(int[] a, int i, int j) {
		int swap = a[i];
		a[i] = a[j];
		a[j] = swap;
	}

	// swaps array elements i and j
	public static void exch(short[] a, int i, int j) {
		short swap = a[i];
		a[i] = a[j];
		a[j] = swap;
	}

	public static void exp(double[] a) {
		for (int i = 0; i < a.length; i++) {
			if (Double.isInfinite(a[i]))
				System.err.println("@Warning: the " + i
						+ "-th value of the array is infinite");
			else if (Double.isNaN(a[i]))
				System.err.println("@Warning: the " + i
						+ "-th value of the array is NaN");
			a[i] = Math.exp(a[i]);
			// if(a[i]==0.0)a[i]=SMALL;
		}
	}// exp

	/**
	 * 
	 * @param a
	 * @return res[0]=index of the max value res[1]=max value;
	 */
	public static double[] findMax(double[] a) {
		double max = Double.MIN_VALUE;
		int index = -1;
		for (int i = 0; i < a.length; i++)
			if (a[i] > max) {
				max = a[i];
				index = i;
			}
		return new double[] { index, max };
	}// findMax

	public static int[] findMax(int[] a) {
		int max = Integer.MIN_VALUE;
		int index = -1;
		for (int i = 0; i < a.length; i++)
			if (a[i] > max) {
				max = a[i];
				index = i;
			}
		return new int[] { index, max };
	}// findMax

	/**
	 * 
	 * @param a
	 * @return res[0]=index of the min value res[1]=min value;
	 */
	public static double[] findMin(double[] a) {
		double max = Double.MAX_VALUE;
		int index = -1;
		for (int i = 0; i < a.length; i++)
			if (a[i] < max) {
				max = a[i];
				index = i;
			}
		return new double[] { index, max };
	}// findMin

	public static void log(double[] a) {
		for (int i = 0; i < a.length; i++)
			if (a[i] <= 0)
				throw new RuntimeException(
						"Cannot compute the log of a value less than zero");
			else
				a[i] = Math.log(a[i]);
	}// log

	public static void main(String[] args) {
		short a[] = { 1, 2, 3, 4, 5 };
		shuffle(a);
		print(a);
	}

	public static void normalize(double[] a) {
		double sum = 0.0;
		for (double element : a)
			sum += element;
		if (Double.isNaN(sum))
			throw new RuntimeException(
					"Cannot normalize a vector with NaN elements ");
		if (Double.isInfinite(sum))
			throw new RuntimeException(
					"Cannot normalize a vector. The sum of the elements is infinite ");
		if (sum != 0)
			for (int i = 0; i < a.length; i++)
				a[i] /= sum;
	}// normalize

	public static void print(double[] m) {
		System.out.println();
		for (double element : m)
			System.out.printf("" + element + "\t");
		System.out.println();
	}// print

	public static void print(int m[]) {
		System.out.println();
		for (int element : m)
			System.out.printf("" + element + "\t");
		System.out.println();
	}// print

	public static void print(short[] m) {
		System.out.println();
		for (short element : m)
			System.out.printf("" + element + "\t");
		System.out.println();
	}// print

	// take as input an array of strings and rearrange them in random order
	public static void shuffle(int[] a) {
		int N = a.length;
		for (int i = 0; i < N; i++) {
			int r = i + (int) (Math.random() * (N - i)); // between i and N-1
			exch(a, i, r);
		}
	}

	// take as input an array of strings and rearrange them in random order
	public static void shuffle(short[] a) {
		int N = a.length;
		for (int i = 0; i < N; i++) {
			int r = i + (int) (Math.random() * (N - i)); // between i and N-1
			exch(a, i, r);
		}
	}

	public static double sum(double[] a) {
		double sum = 0.0;
		for (double element : a)
			sum += element;
		return sum;
	}// sum

	public static void toDoubleArray(double[] values,
			LinkedList<Double> valueList) {
		int i = 0;
		for (Double double1 : valueList)
			values[i++] = double1;
	}// toDoubleArray

	public static void toIntArray(int[] indexes, LinkedList<Integer> indexList) {
		int i = 0;
		for (Integer integer : indexList)
			indexes[i++] = integer;
	}// toDoubleArray
}