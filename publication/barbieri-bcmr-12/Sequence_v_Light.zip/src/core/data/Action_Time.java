/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package core.data;

public class Action_Time extends Action {

	private static final long serialVersionUID = 983725735511L;

	protected long timeStamp;

	public Action_Time() {
		// Do nothing!
	}

	public Action_Time(int userId, int itemId) {
		super(userId, itemId);

		timeStamp = 0;
	}

	public Action_Time(int userId, int itemId, long timeStamp) {
		super(userId, itemId);

		this.timeStamp = timeStamp;
	}

	@Override
	public Action_Time getCopy() {
		return new Action_Time(userId, itemId, timeStamp);
	}

	@Override
	public long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(int ts) {
		timeStamp = ts;
	}

	@Override
	public String toString() {
		return "[userId=" + userId + ", itemId=" + itemId + ", timestamp="
				+ timeStamp + "]";
	}
}