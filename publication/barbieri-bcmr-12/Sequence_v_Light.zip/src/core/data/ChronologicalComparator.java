/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package core.data;

import java.util.Comparator;

public class ChronologicalComparator implements Comparator<Action> {

	@Override
	public int compare(Action o1, Action o2) {
		if (o1.getTimeStamp() < o2.getTimeStamp())
			return -1;

		if (o1.getTimeStamp() > o2.getTimeStamp())
			return 1;

		if (o1.getUserId() < o2.getUserId())
			return -1;

		if (o1.getUserId() > o2.getUserId())
			return 1;

		if (o1.getItemId() < o2.getItemId())
			return -1;

		if (o1.getItemId() > o2.getItemId())
			return 1;

		return 0;
	}
}