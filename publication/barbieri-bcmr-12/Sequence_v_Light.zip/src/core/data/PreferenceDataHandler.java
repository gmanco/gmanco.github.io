/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package core.data;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class PreferenceDataHandler implements Serializable {

	public enum Time_Format implements Serializable {
		None, Unix_Timestamp, Millis, Date;
	}

	private static final long serialVersionUID = -6675362942787324742L;

	public static void printUsage() {
		System.out.println("Preference Data Reader");
		System.out.println("<dataPath> <readConf>");
	}

	protected TreeSet<Integer> userSet;
	protected TreeSet<Integer> itemSet;
	protected int nUsers = 0;
	protected int nItems = 0;
	protected int size = 0;
	protected int nStars = 0;
	protected Action[][] data;

	protected int nu[];
	protected int ni[];
	protected Int2IntOpenHashMap itemIdToIndex; // index --> itemId
	protected Int2IntOpenHashMap userIdToIndex; // index --> userId
	protected String header;
	protected Time_Format tf;
	protected int index_of_user_id;
	protected int index_of_item_id;
	protected int index_of_timestamp;

	protected String separator;

	public PreferenceDataHandler() {
		userSet = new TreeSet<Integer>();
		itemSet = new TreeSet<Integer>();
		data = null;
	}

	public PreferenceDataHandler(final int nUsers, final int nItems,
			final int size) {
		this.nUsers = nUsers;
		this.size = size;
		this.nItems = nItems;
		userSet = new TreeSet<Integer>();
		itemSet = new TreeSet<Integer>();
		data = new Action[nUsers][];
	}

	public boolean existsAction(final int userId, final int itemId) {
		final Action[] actionList = data[userIdToIndex.get(userId)];
		for (final Action a : actionList)
			if (a.itemId == itemId)
				return true;
		return false;

	}// existsAction

	public String formatAction(final Action a) {
		String s = "";
		if (index_of_user_id == 0)
			s += a.userId + separator;
		else if (index_of_item_id == 0)
			s += a.itemId + separator;
		else if (index_of_timestamp == 0)
			s += a.getTimeStamp() + separator;

		if (index_of_user_id == 1)
			s += a.userId + separator;
		else if (index_of_item_id == 1)
			s += a.itemId + separator;
		else if (index_of_timestamp == 1)
			s += a.getTimeStamp() + separator;

		if (index_of_user_id == 2)
			s += a.userId + separator;
		else if (index_of_item_id == 2)
			s += a.itemId + separator;
		else if (index_of_timestamp == 2)
			s += a.getTimeStamp() + separator;

		if (index_of_user_id == 3)
			s += a.userId;
		else if (index_of_item_id == 3)
			s += a.itemId;
		else if (index_of_timestamp == 3)
			s += a.getTimeStamp();
		return s;
	}// formatAction

	public Action[] getActionsForUser(final int userId) {
		return data[userIdToIndex.get(userId)];
	}// getActionsForUser

	public Action[][] getData() {
		return data;
	}

	public String getHeader() {
		return header;
	}

	public void getInfo() {
		Integer[] users;
		Integer[] items;
		users = userSet.toArray(new Integer[nUsers]);
		items = itemSet.toArray(new Integer[nItems]);

		double avgRatingxUser = 0;
		int minRatingxUser = Integer.MAX_VALUE;
		int maxRatingsxUser = Integer.MIN_VALUE;
		for (int u = 0; u < nUsers; u++) {
			final int nRatingPerUser = getNActionsForUser(users[u]);
			avgRatingxUser += nRatingPerUser;
			if (minRatingxUser > nRatingPerUser)
				minRatingxUser = nRatingPerUser;
			if (maxRatingsxUser < nRatingPerUser)
				maxRatingsxUser = nRatingPerUser;

		}
		avgRatingxUser /= nUsers;

		double avgRatingPerItem = 0.0;
		int minNRatingsxItem = Integer.MAX_VALUE;
		int maxNratingsxItem = Integer.MIN_VALUE;

		for (int i = 0; i < nItems; i++) {
			final int nRatingxItem = getNActionsForItem(items[i]);
			avgRatingPerItem += nRatingxItem;
			if (nRatingxItem < minNRatingsxItem)
				minNRatingsxItem = nRatingxItem;
			if (nRatingxItem > maxNratingsxItem)
				maxNratingsxItem = nRatingxItem;
		}
		avgRatingPerItem /= nItems;

		double avgTimeBetween2EvalUser = 0D;
		Action[] obsForUser;
		int nUserValidi = 0;
		final Integer[] userSet = getUserSet().toArray(new Integer[nUsers]);
		for (int u = 0; u < nUsers; u++) {
			obsForUser = getActionsForUser(userSet[u]);
			final long min = ((Action_Time) obsForUser[0]).getTimeStamp();
			final long max = ((Action_Time) obsForUser[obsForUser.length - 1])
					.getTimeStamp();
			if (obsForUser.length > 2) {
				avgTimeBetween2EvalUser += (max - min)
						/ (obsForUser.length - 1);
				nUserValidi++;
			}
		}
		avgTimeBetween2EvalUser /= nUserValidi;

		System.out.println("  . . . Dataset Set info . . .");
		System.out.println("#users \t" + nUsers);
		System.out.println("#items \t" + nItems);
		System.out.println("#preferences \t" + size);
		System.out.println("Avg #ratings user \t" + avgRatingxUser);
		System.out.println("Avg #ratings item \t" + avgRatingPerItem);
		System.out.println("Min #ratings user \t" + minRatingxUser);
		System.out.println("Max #ratings user \t" + maxRatingsxUser);
		System.out.println("Min #ratings item \t" + minNRatingsxItem);
		System.out.println("Max #ratings item \t" + maxNratingsxItem);
		System.out.println("AVG TIME B 2 EVAL USER \t"
				+ avgTimeBetween2EvalUser);

		System.out.println(" . . . . . . . . . . . . . . . . ");
	}

	public Int2IntOpenHashMap getItemIndex() {
		return itemIdToIndex;
	}// getItemIndex

	public TreeSet<Integer> getItemSet() {
		return itemSet;
	}

	public int getNActionsForItem(final int itemId) {
		final Integer i = itemIdToIndex.get(itemId);
		if (i == null)
			return 0;
		return ni[i];
	}// getNRatingsForItem

	public int getNActionsForUser(final int userId) {
		return nu[userIdToIndex.get(userId)];
	}

	public int getNItems() {
		return itemSet.size();
	}

	// getNRatingsForUser

	public int getNStars() {
		return nStars;
	}

	public int getNUsers() {
		return userSet.size();
	}

	public int getSize() {
		return size;
	}

	public Time_Format getTimeFormat() {
		return tf;
	}

	public Int2IntOpenHashMap getUserIndex() {
		return userIdToIndex;
	}// getUserIndex

	public TreeSet<Integer> getUserSet() {
		return userSet;
	}

	public void read(final String dataFile, final String readConfigFile)
			throws Exception {
		System.out.println("Reading File " + dataFile + " ....");

		final HashMap<Integer, ArrayList<Action>> tempData = new HashMap<Integer, ArrayList<Action>>();

		final Properties properties = new Properties();
		try {
			properties.load(new FileInputStream(readConfigFile));
		} catch (final IOException e) {
		}

		index_of_user_id = -1;
		index_of_item_id = -1;
		index_of_timestamp = -1;

		boolean skip_first_line = false;

		index_of_user_id = Integer.parseInt(properties
				.getProperty("index_of_user_id"));
		index_of_item_id = Integer.parseInt(properties
				.getProperty("index_of_item_id"));
		index_of_timestamp = Integer.parseInt(properties
				.getProperty("index_of_timestamp"));

		if (properties.getProperty("skip_first_line").equalsIgnoreCase("true"))
			skip_first_line = true;
		SimpleDateFormat dfm = null;
		String time_f = null;
		if (index_of_timestamp >= 0) {

			time_f = properties.getProperty("timestamp_format").trim();
			if (time_f.equalsIgnoreCase("None"))
				tf = Time_Format.None;
			else if (time_f.equalsIgnoreCase("unix_timestamp"))
				tf = Time_Format.Unix_Timestamp;
			else if (time_f.equalsIgnoreCase("millisecs"))
				tf = Time_Format.Millis;
			else {
				tf = Time_Format.Date;
				dfm = new SimpleDateFormat(time_f);
			}
		}

		separator = properties.getProperty("separator").trim();
		if (separator.equalsIgnoreCase("tab"))
			separator = "\t";
		final BufferedReader br = new BufferedReader(new FileReader(dataFile));
		String line = br.readLine();
		if (skip_first_line) {
			header = "" + line.toString();
			line = br.readLine();
		}

		StringTokenizer st = null;

		final String[] tokens = new String[4];

		Action po = null;
		ArrayList<Action> al;
		size = 0;
		while (line != null) {
			if (line.length() == 0) {
				line = br.readLine();
				continue;
			}
			st = new StringTokenizer(line, separator);
			int index = 0;
			while (st.hasMoreTokens()) {
				tokens[index] = st.nextToken();
				index++;
			}

			final int userId = Integer.parseInt(tokens[index_of_user_id]);
			final int itemId = Integer.parseInt(tokens[index_of_item_id]);

			long timeStamp = 0L;

			if (index_of_timestamp >= 0)
				if (tf == Time_Format.Date)
					timeStamp = dfm.parse(tokens[index_of_timestamp]).getTime() / 1000;
				else
					timeStamp = Long.parseLong(tokens[index_of_timestamp]);

			po = new Action_Time(userId, itemId, timeStamp);

			if (po != null) {

				al = tempData.get(userId);
				if (al == null) {
					al = new ArrayList<Action>();
					tempData.put(userId, al);
				}
				al.add(po);
				size++;
				userSet.add(userId);
				itemSet.add(itemId);
			}

			line = br.readLine();
		}// for each line
		System.out.println(size);
		nUsers = userSet.size();
		nItems = itemSet.size();

		nu = new int[nUsers];
		ni = new int[nItems];
		data = new Action[nUsers][];

		userIdToIndex = new Int2IntOpenHashMap();
		int u = 0;
		for (final int userId : userSet) {
			userIdToIndex.put(userId, u);
			u++;
		}
		itemIdToIndex = new Int2IntOpenHashMap();
		int i = 0;
		for (final int itemId : itemSet) {
			itemIdToIndex.put(itemId, i);
			i++;
		}
		final ChronologicalComparator cc = new ChronologicalComparator();
		for (final int userId : userSet) {
			final int userIndex = userIdToIndex.get(userId);
			al = tempData.get(userId);
			Collections.sort(al, cc);
			data[userIndex] = new Action[al.size()];
			for (int j = 0; j < al.size(); j++) {
				final Action a = al.get(j);
				ni[itemIdToIndex.get(a.itemId)]++;
				data[userIndex][j] = a;
			}
			nu[userIndex] = al.size();

		}

		System.out.println("Dataset Loaded.");
	}// read
}// PreferenceDataHandler
