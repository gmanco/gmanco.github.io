/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package core.data;

import java.io.Serializable;

public class Action implements Serializable {

	private static final long serialVersionUID = -7432602937311L;

	protected int userId;
	protected int itemId;

	public Action() {
		// Do nothing!
	}

	public Action(int userId, int itemId) {
		this.userId = userId;
		this.itemId = itemId;
	}

	public Action(int userId, int itemId, int timeStamp) {
		this.userId = userId;
		this.itemId = itemId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Action other = (Action) obj;
		if (itemId != other.itemId)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}

	public Action getCopy() {
		return new Action(userId, itemId);
	}

	public int getItemId() {
		return itemId;
	}

	public double getRating() {
		return 1;
	}

	public long getTimeStamp() {
		return 0L;
	}

	public int getUserId() {
		return userId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + itemId;
		result = prime * result + userId;
		return result;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public void setTimeStamp(long ts) {
		// to nothing
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "[userId=" + userId + ", itemId=" + itemId + "]";
	}
}