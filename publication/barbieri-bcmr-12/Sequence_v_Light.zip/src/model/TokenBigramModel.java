/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package model;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.util.LinkedList;

import core.data.Action;
import core.data.PreferenceDataHandler;

public class TokenBigramModel implements Model {

	private static final long serialVersionUID = -9876454562792233L;

	private Int2IntOpenHashMap userIdToIndex;
	private Int2IntOpenHashMap itemIdToIndex;
	private double[][] itemAvg; // N x K

	/**
	 * number of topics
	 */
	private int nTopics;

	/**
	 * Dirichlet parameter (document--topic associations) Dirichlet parameter
	 * (user-topics associations)
	 */
	private double alpha[];

	/**
	 * Dirichlet parameter (topic--term associations) Dirichlet parameter
	 * (topic--item associations)
	 */
	private double symmetricBeta;
	LinkedList<Short>[] topicAssignments; // M X N

	private double[][] theta; // M x K

	private double[][][] phi;

	public TokenBigramModel(int nTopics) {
		this.nTopics = nTopics;
	}

	public double computeLogLikelihood(PreferenceDataHandler data) {
		int previousItem; // Item
		int currentItem; // Item

		Action[] observationForUser;

		double observationProbability;

		double llk = 0d;
		Integer[] userSet = data.getUserSet().toArray(
				new Integer[data.getNUsers()]);

		for (int u = 0; u < data.getNUsers(); ++u) {
			observationForUser = data.getActionsForUser(userSet[u]);
			int i = 0;
			previousItem = -1;

			for (Action po : observationForUser) {
				currentItem = itemIdToIndex.get(po.getItemId());
				observationProbability = 0d;
				if (i > 0) {
					for (int k = 0; k < nTopics; ++k)
						observationProbability += phi[k][previousItem][currentItem]
								* theta[u][k];
					llk += Math.log(observationProbability);
				}
				previousItem = currentItem;
				i++;
			}
		}
		return llk;
	}// computeLogLikelihood

	public double computePerplexity(double logLikelihood,
			PreferenceDataHandler data) {
		return Math.exp(-1 * logLikelihood / data.getSize());
	}

	public double[] getAlpha() {
		return alpha;
	}

	public double[][] getItemAvg() {
		return itemAvg;
	}

	public Int2IntOpenHashMap getItemIdToIndex() {
		return itemIdToIndex;
	}

	public String getName() {
		return "Token Bigram" + nTopics;
	}

	public int getnTopics() {
		return nTopics;
	}

	public int getNTopics() {
		return nTopics;
	}

	public double[][][] getPhi() {
		return phi;
	}

	public double getSymmetricBeta() {
		return symmetricBeta;
	}

	public double[][] getTheta() {
		return theta;
	}

	public LinkedList<Short>[] getTopicAssignments() {
		return topicAssignments;
	}

	public Int2IntOpenHashMap getUserIdToIndex() {
		return userIdToIndex;
	}

	public void setAlpha(double[] alpha) {
		this.alpha = alpha;
	}

	public void setItemAvg(double[][] itemAvg) {
		this.itemAvg = itemAvg;
	}

	public void setItemIdToIndex(Int2IntOpenHashMap itemIdToIndex) {
		this.itemIdToIndex = itemIdToIndex;
	}

	public void setnTopics(int nTopics) {
		this.nTopics = nTopics;
	}

	public void setPhi(double[][][] phi) {
		this.phi = phi;
	}

	public void setSymmetricBeta(double symmetricBeta) {
		this.symmetricBeta = symmetricBeta;
	}

	public void setTheta(double[][] theta) {
		this.theta = theta;
	}

	public void setTopicsAssignments(LinkedList<Short>[] z) {
		topicAssignments = z;
	}

	public void setUserIdToIndex(Int2IntOpenHashMap userIdToIndex) {
		this.userIdToIndex = userIdToIndex;
	}
}