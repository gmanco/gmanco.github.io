/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package model;

import java.io.Serializable;

import core.data.PreferenceDataHandler;

public interface Model extends Serializable {

	public double computeLogLikelihood(PreferenceDataHandler data);

	public double computePerplexity(double logLikelihood,
			PreferenceDataHandler data);

	public String getName();

	public int getNTopics();
}