/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package model;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.util.LinkedList;

import core.data.Action;
import core.data.PreferenceDataHandler;

public class TokenBiTopicModel implements Model {

	private static final long serialVersionUID = -64830200022651L;

	private Int2IntOpenHashMap userIdToIndex;
	private Int2IntOpenHashMap itemIdToIndex;
	private double[][] itemAvg; // N x K

	/**
	 * number of topics
	 */
	private int nTopics;

	/**
	 * Dirichlet parameter (document--topic associations) Dirichlet parameter
	 * (user-topics associations)
	 */
	private double alpha[];

	/**
	 * Dirichlet parameter (topic--term associations) Dirichlet parameter
	 * (topic--item associations)
	 */
	private double symmetricBeta;
	private LinkedList<Short>[] topicAssignments; // [SUM(Nd for each d)][K]
	private double[][] theta; // M x K
	private double[][][] phi;

	public TokenBiTopicModel(int nTopics) {
		this.nTopics = nTopics;
	}

	public double computeLogLikelihood(PreferenceDataHandler data) {
		int j; // User
		int s; // Item

		Action[] observationForUser;

		double observationProbability;

		double llk = 0d;
		Integer[] userSet = data.getUserSet().toArray(
				new Integer[data.getNUsers()]);

		for (j = 0; j < data.getNUsers(); ++j) {
			observationForUser = data.getActionsForUser(userSet[j]);
			int i = 0;
			for (Action po : observationForUser) {
				s = itemIdToIndex.get(po.getItemId());
				observationProbability = 0d;
				if (i > 0) {
					for (int k = 0; k < nTopics; ++k)
						for (int kPrec = 0; kPrec < nTopics; kPrec++)
							observationProbability += theta[j][k]
									* phi[s][kPrec][k] * theta[j][kPrec];
					llk += Math.log(observationProbability);
				}
				i++;
			}
		}

		return llk;
	}

	public double computePerplexity(double logLikelihood,
			PreferenceDataHandler data) {
		return Math.exp(-1 * logLikelihood / data.getSize());
	}

	public double[] getAlpha() {
		return alpha;
	}

	public double[][] getItemAvg() {
		return itemAvg;
	}

	public Int2IntOpenHashMap getItemIdToIndex() {
		return itemIdToIndex;
	}

	public String getName() {
		return "Token Bitopic " + nTopics;
	}

	public int getnTopics() {
		return nTopics;
	}

	public int getNTopics() {
		return nTopics;
	}

	public double[][][] getPhi() {
		return phi;
	}

	public double getSymmetricBeta() {
		return symmetricBeta;
	}

	public double[][] getTheta() {
		return theta;
	}

	public LinkedList<Short>[] getTopicAssignments() {
		return topicAssignments;
	}

	public Int2IntOpenHashMap getUserIdToIndex() {
		return userIdToIndex;
	}

	public void setAlpha(double[] alpha) {
		this.alpha = alpha;
	}

	public void setItemAvg(double[][] itemAvg) {
		this.itemAvg = itemAvg;
	}

	public void setItemIdToIndex(Int2IntOpenHashMap itemIdToIndex) {
		this.itemIdToIndex = itemIdToIndex;
	}

	public void setnTopics(int nTopics) {
		this.nTopics = nTopics;
	}

	public void setPhi(double[][][] phi) {
		this.phi = phi;
	}

	public void setSymmetricBeta(double symmetricBeta) {
		this.symmetricBeta = symmetricBeta;
	}

	public void setTheta(double[][] theta) {
		this.theta = theta;
	}

	public void setTopicsAssignments(LinkedList<Short>[] z) {
		topicAssignments = z;
	}

	public void setUserIdToIndex(Int2IntOpenHashMap userIdToIndex) {
		this.userIdToIndex = userIdToIndex;
	}
}