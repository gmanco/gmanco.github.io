/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package model;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import core.data.PreferenceDataHandler;

public class TopicBigramModel implements Model {

	private static final long serialVersionUID = 41246128562367347L;

	private Int2IntOpenHashMap userIdToIndex;
	private Int2IntOpenHashMap itemIdToIndex;

	/**
	 * number of topics
	 */
	private int nTopics;

	/**
	 * Dirichlet parameter (document--topic associations) Dirichlet parameter
	 * (user-topics associations)
	 */
	private double alpha[][];

	/**
	 * Dirichlet parameter (topic--term associations) Dirichlet parameter
	 * (topic--item associations)
	 */
	private double beta[];
	private short[][] topicAssignments; // M X N
	private double[][][] theta; // M x K
	private double[][] phi;

	public TopicBigramModel(int nTopics) {
		this.nTopics = nTopics;
	}

	/**
	 * Computes the log-likelihood of the model.
	 * 
	 * @return The log-likelihood.
	 */
	@Override
	public double computeLogLikelihood(PreferenceDataHandler data) {
		return 0;
	}

	@Override
	public double computePerplexity(double logLikelihood,
			PreferenceDataHandler data) {
		return Math.exp(-1 * logLikelihood / data.getSize());
	}

	public double[][] getAlpha() {
		return alpha;
	}

	public double[] getBeta() {
		return beta;
	}

	public Int2IntOpenHashMap getItemIdToIndex() {
		return itemIdToIndex;
	}

	public String getName() {
		return "TopicBigram" + nTopics;
	}

	public int getnTopics() {
		return nTopics;
	}

	public int getNTopics() {
		return nTopics;
	}

	public double[][] getPhi() {
		return phi;
	}

	public double[][][] getTheta() {
		return theta;
	}

	public short[][] getTopicAssignments() {
		return topicAssignments;
	}

	public Int2IntOpenHashMap getUserIdToIndex() {
		return userIdToIndex;
	}

	public void setAlpha(double[][] alpha) {
		this.alpha = alpha;
	}

	public void setBeta(double[] beta) {
		this.beta = beta;
	}

	public void setItemIdToIndex(Int2IntOpenHashMap itemIdToIndex) {
		this.itemIdToIndex = itemIdToIndex;
	}

	public void setnTopics(int nTopics) {
		this.nTopics = nTopics;
	}

	public void setPhi(double[][] phi) {
		this.phi = phi;
	}

	public void setTheta(double[][][] theta) {
		this.theta = theta;
	}

	public void setTopicsAssignments(short[][] z) {
		topicAssignments = z;
	}

	public void setUserIdToIndex(Int2IntOpenHashMap userIdToIndex) {
		this.userIdToIndex = userIdToIndex;
	}
}