/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package inference;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Random;

import model.TokenBigramModel;
import cern.colt.matrix.impl.SparseObjectMatrix2D;
import core.data.Action;
import core.data.PreferenceDataHandler;
import core.io.IOManager;
import core.util.ArrayUtilities;

/**
 * This class infers a LDA model parameters, with the assumption that each item
 * depends on its topic and the previous item in the sequence.
 * 
 * @author Ettore Ritacco
 * @version 2.0.0
 */
public class TokenBigramInference {

	protected static int[] convert2index(Action[] actions,
			Int2IntOpenHashMap itemIdToIndex) {
		int[] ret = new int[actions.length];

		for (int i = 0, n = actions.length; i < n; ++i)
			ret[i] = itemIdToIndex.get(actions[i].getItemId());

		return ret;
	}

	/**
	 * Estimates the Digamma value of a real positive number.
	 * 
	 * @param x
	 *            Input of the Digamma function.
	 * @return The Digamma value for <code>x</code>.
	 */
	/*
	 * private static double digamma(double x) { double pow = 1; double ret =
	 * Math.log(x) - .5 * x;
	 * 
	 * for (int i = 0, n = BERNOULLI_NUMBERS.length; i < n; ++i) { pow *= x * x;
	 * ret -= BERNOULLI_NUMBERS[i] / pow; }
	 * 
	 * return ret; }
	 */
	public static double digamma(double x) {
		double p;
		assert x > 0;
		x = x + 6;
		p = 1 / (x * x);
		p = (((0.004166666666667 * p - 0.003968253986254) * p + 0.008333333333333)
				* p - 0.083333333333333)
				* p;
		p = p + Math.log(x) - 0.5 / x - 1 / (x - 1) - 1 / (x - 2) - 1 / (x - 3)
				- 1 / (x - 4) - 1 / (x - 5) - 1 / (x - 6);
		return p;
	}// digamma

	/**
	 * Main program for testing purpose.
	 * 
	 * @param args
	 *            Empty
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 5) {
			printUsage();
			return;
		}
		System.out.println("Token Bigram Inference");

		long start = System.currentTimeMillis();

		PreferenceDataHandler data = new PreferenceDataHandler();
		data.read(args[0], args[1]);
		data.getInfo();

		TokenBigramInference inf = new TokenBigramInference();

		int nTopics = Integer.parseInt(args[2]);
		String output = args[3];
		inf.nTopics = nTopics;
		inf.output = output;

		System.out.println("N topics\t" + nTopics);
		System.out.println("Output \t" + output);

		inf.runInference(data, args[4]);

		long end = System.currentTimeMillis();
		System.out.println("Building Time: " + (end - start));

	}

	/**
	 * Return a string representation of a real number with a specific number of
	 * decimal digits.
	 * 
	 * @param d
	 *            Number to convert in <code>{@link java.lang.String}</code>.
	 * @param i
	 *            Number of decimal digits to dislpay.
	 * @return A string representation of <code>d</code> with <code>i</code>
	 *         decimal digits
	 */
	private static String padd(double d, int i) {
		long pow = Math.round(Math.pow(10, i));

		d *= pow;
		d = (double) Math.round(d) / pow;

		return String.valueOf(d);
	}

	public static void printUsage() {
		System.out.println("Token Bigram Inference");
		System.out.println("<training> <readConf> <nTopics> <output> <params>");
	}

	/**
	 * Convert a collection of <code>{@link java.lang.Integer}</code> values
	 * into an array of <code>int</code>.
	 * 
	 * @param c
	 *            Collection of <code>{@link java.lang.Integer}</code> values.
	 * @return an array of <code>int</code>.
	 */
	protected static int[] toIntArray(Collection<Integer> c) {
		int[] ret = new int[c.size()];
		int i = 0;

		for (Integer value : c)
			ret[i++] = value;

		return ret;
	}

	/**
	 * Dirichlet parameter, user-topic associations.
	 */
	protected double[] alpha; // [M]

	/**
	 * Simplified version of the Dirichlet parameter alpha vector: user-topic
	 * associations.
	 */
	protected double symmetricAlpha;

	/**
	 * Cumulative statistics of alpha.
	 */
	protected double alphaSum;
	/**
	 * Simplified version of the Dirichlet parameter beta matrix: topic-itemPair
	 * associations.
	 */
	protected double symmetricBeta;
	/**
	 * Burn-in period.
	 */
	protected int burnIn = 100;

	/**
	 * Counter: number of item in the user profile j.
	 */
	protected int[] counterOfItemsPerUserProfile; // [M]
	/**
	 * Counter: number of item in the user profile j assigned to topic k.
	 */
	protected int[][] counterOfItemsPerUserProfileAndTopics; // [M][K]
	/**
	 * Counter: number of assignments to topic k.
	 */
	protected int[][] counterOfTopicAssignements; // [K][N]
	/**
	 * Counter: number times that a topic is assigned to a pair of item.
	 */
	protected SparseObjectMatrix2D[] counterOfTopicAssignementsToPairsOfItems;
	// [K][V + 1][V]
	// TODO da cambiare in mappe

	/**
	 * Training data handler.
	 */
	protected PreferenceDataHandler data;

	/**
	 * Map<key: item id, value: item index in the inner format>.
	 */
	protected Int2IntOpenHashMap itemIdToIndex;

	/**
	 * Max number of iterations.
	 */
	protected int maxIterations = 1000;

	/**
	 * Number of distinct items.
	 */
	protected int nItems; // V

	/**
	 * Training data size.
	 */
	protected int nRatingsTraining;

	/**
	 * Number of topics.
	 */
	protected int nTopics; // K

	/**
	 * Number of distinct users.
	 */
	protected int nUsers; // M

	/**
	 * Multinomial parameters Phi.
	 */
	protected double[][][] phi; // [K][V + 1][V], (k, r, s)

	/**
	 * Random number generator.
	 */
	protected Random rand;

	/**
	 * Sample lag.
	 */
	protected int sampleLag = 10;

	/**
	 * Multinomial parameters Theta.
	 */
	protected double[][] theta; // [M][K]

	/**
	 * Topic assignments for each pair (user, item).
	 */
	// [user]=>list of topic
	protected LinkedList<Short>[] topicAssignments; // [SUM(Nd for each d)][K]

	// TODO da cambiare in mappe
	protected boolean updateHyperParams = true;

	/**
	 * Map<key: user id, value: user index in the inner format>.
	 */
	protected Int2IntOpenHashMap userIdToIndex;

	/**
	 * Map<key: user index in the inner format, value: user id>.
	 */
	protected int[] userSet;

	/**
	 * Log-likelihood of the estimated model
	 */
	protected double llk;

	/**
	 * Perplexity of the estimated model
	 */
	protected double perplexity;
	protected int maxAlphaUpdateIterations = Integer.MAX_VALUE;
	protected String output;
	public static boolean store = true;
	protected double[][][] sumPhi;
	protected double[][] sumTheta; // [M][K]
	protected int sampleLagIterations;

	/**
	 * Builds a <code>latentFactorModels.SEQ1_Model</code> object whose
	 * parameters are computed via the inference.
	 * 
	 * @param output
	 *            Output File Log.
	 * @return The <code>latentFactorModels.SEQ1_Model</code> object
	 * 
	 * @throws Exception
	 *             Thrown if <code>output</code> file does not exist.
	 */
	protected TokenBigramModel buildModel(String output) throws Exception {
		TokenBigramModel seq = new TokenBigramModel(nTopics);
		seq.setAlpha(alpha);
		seq.setSymmetricBeta(symmetricBeta);
		seq.setItemIdToIndex(itemIdToIndex);
		seq.setPhi(phi);
		seq.setTheta(theta);
		seq.setUserIdToIndex(userIdToIndex);
		seq.setTopicsAssignments(topicAssignments);

		if (store)
			IOManager.writeObjectOnFile(seq, output);

		return seq;
	}

	/**
	 * Runs the burn-in period for the inferecen.
	 */
	protected void burnIn() {
		int iteration;
		double percent;
		double oldPercent;

		System.out.println("Starting burn-in.");
		oldPercent = 0;

		for (iteration = 0; iteration < burnIn; ++iteration) {
			percent = (double) iteration / burnIn;

			if (percent > oldPercent + 0.1) {
				System.out.println("Burn-in: " + padd(percent * 100, 1) + "%");
				oldPercent = percent;
			}

			gibbsLDA();

			if (updateHyperParams)
				updateAlpha();
		}

		System.out.println("Burn-in: 100.0% complete");
	}

	/**
	 * Check if input parameters are valid.
	 * 
	 * @param output
	 *            Output file name.
	 */
	private void checkParameters(String output) {
		System.out.println("Params");
		System.out.println("N_Topics\t" + nTopics);
		System.out.println("Alpha\t" + symmetricAlpha);
		System.out.println("Beta\t" + symmetricBeta);
		System.out.println("N_Max_Iterations\t" + maxIterations);
		System.out.println("Burn in\t" + burnIn);
		System.out.println("Sample Lag\t" + sampleLag);
		System.out.println("Update Alpha\t" + updateHyperParams);
		System.out.println("Output\t" + output);

		if (nTopics <= 0)
			throw new IllegalArgumentException(
					"The number of topics must be a non-negative integer.");

		if (symmetricAlpha <= 0)
			throw new IllegalArgumentException(
					"The symmetric Alpha parameter must be a non-negative real.");

		if (symmetricBeta <= 0)
			throw new IllegalArgumentException(
					"The symmetric Beta parameter must be a non-negative real.");

		if (maxIterations <= 0 || burnIn >= maxIterations)
			throw new IllegalArgumentException(
					"The maximum number of iteration"
							+ " must be a non-negative integer and greater"
							+ " than the burn-in's number of iteration.");

		if (burnIn <= 0)
			throw new IllegalArgumentException("The burn-in's number "
					+ "of iteration must be a non-negative integer.");

		if (sampleLag <= 0 || sampleLag >= maxIterations - burnIn)
			throw new IllegalArgumentException("The sample lag must be a "
					+ "non-negative integer and less than the"
					+ " difference between maxIterations and burnIn.");

		if (store)
			try {
				File f = new File(output);
				if (!f.exists())
					if (!f.createNewFile())
						throw new IllegalArgumentException(
								"Output file does not exist or invalid.");

			} catch (IOException e) {
				throw new IllegalArgumentException(
						"Output file does not exist or invalid.", e);
			}
	}

	/**
	 * Computes the log-likelihood of the model.
	 * 
	 * @return The log-likelihood.
	 */
	public double computeLogLikelihood() {
		int u, n; // User
		int r; // Item
		int k, t;

		int[] observationForUser;

		double prob1, prob2;

		double llk = 0d;
		final int[] userSet = toIntArray(data.getUserSet());
		LinkedList<String> listErrs = new LinkedList<String>();

		for (u = 0, n = data.getNUsers(); u < n; ++u) {
			observationForUser = convert2index(data
					.getActionsForUser(userSet[u]), data.getItemIndex());

			prob2 = 0;

			for (k = 0, t = nTopics; k < t; ++k) {
				prob1 = 0;
				r = data.getNItems(); // epsilon

				for (int s : observationForUser) {
					prob1 += Math.log(phi[k][r][s]);
					r = s;
				}

				prob2 += theta[u][k] * Math.exp(prob1);
			}

			prob2 = Math.log(prob2);

			if (!Double.isInfinite(prob2) && !Double.isNaN(prob2))
				llk += prob2;
			else
				listErrs.add("(Index:" + u + ", id:" + userSet[u] + ")");
		}

		if (listErrs.size() > 0)
			System.out.println("Warning #" + listErrs.size() + ": " + listErrs);

		return llk;
	}

	/**
	 * Computes the perplexity of the model.
	 * 
	 * @return The perplexity.
	 */
	protected double computePerplexity(double llk) {
		return Math.exp(-llk / data.getSize());
	}

	/**
	 * Computes estimated topic-item associations.
	 */
	protected void computePhi(int sampleIteration) {
		int k; // Topic.
		int r; // Item.
		int s; // Item.
		double den;

		Integer tmpInteger;

		if (sampleIteration == 0)
			for (k = 0; k < nTopics; ++k)
				for (r = 0; r < nItems + 1; ++r) {
					den = counterOfTopicAssignements[k][r] + nItems
							* symmetricBeta;

					for (s = 0; s < nItems; ++s) {
						tmpInteger = (Integer) counterOfTopicAssignementsToPairsOfItems[k]
								.get(r, s);

						phi[k][r][s] = tmpInteger == null ? symmetricBeta
								: tmpInteger + symmetricBeta;

						phi[k][r][s] /= den;
					}
				}
		else {
			double newPhi;

			for (k = 0; k < nTopics; ++k)
				for (r = 0; r < nItems + 1; ++r) {
					den = counterOfTopicAssignements[k][r] + nItems
							* symmetricBeta;

					for (s = 0; s < nItems; ++s) {
						tmpInteger = (Integer) counterOfTopicAssignementsToPairsOfItems[k]
								.get(r, s);

						newPhi = tmpInteger == null ? symmetricBeta
								: tmpInteger + symmetricBeta;

						newPhi /= den;

						sumPhi[k][r][s] += newPhi;

						phi[k][r][s] = sumPhi[k][r][s] / sampleIteration;
					}
				}
		}
	}

	/**
	 * Computes estimated user-topic associations.
	 */
	protected void computeTheta(int sampleIteration) {
		int j; // User.
		int k; // Topic.

		if (sampleIteration == 0)
			for (j = 0; j < nUsers; ++j)
				for (k = 0; k < nTopics; ++k)
					theta[j][k] = (counterOfItemsPerUserProfileAndTopics[j][k] + alpha[k])
							/ (counterOfItemsPerUserProfile[j] + alphaSum);
		else {
			double newTheta;

			for (j = 0; j < nUsers; ++j)
				for (k = 0; k < nTopics; ++k) {
					newTheta = (counterOfItemsPerUserProfileAndTopics[j][k] + alpha[k])
							/ (counterOfItemsPerUserProfile[j] + alphaSum);

					sumTheta[j][k] += newTheta;
					theta[j][k] = sumTheta[j][k] / sampleIteration;
				}
		}
	}

	/**
	 * Estimates the multinomial parameters (Theta, Phi) and the log-likelihood
	 * and perplexity of the model.
	 */
	protected void estimateMultinomialParametersAndStatistics(
			int sampleIteration) {
		computeTheta(sampleIteration);
		computePhi(sampleIteration);
		// llk = computeLogLikelihood();
		// perplexity = computePerplexity(llk);
	}

	public double[] getAlpha() {
		return alpha;
	}

	public int[][] getCounterOfTopicAssignements() {
		return counterOfTopicAssignements;
	}

	public SparseObjectMatrix2D[] getCounterOfTopicAssignementsToPairsOfItems() {
		return counterOfTopicAssignementsToPairsOfItems;
	}

	public int getnTopics() {
		return nTopics;
	}

	public double[][][] getPhi() {
		return phi;
	}

	public double getSymmetricBeta() {
		return symmetricBeta;
	}

	/**
	 * Runs the Gibbs sampling procedure for each topic assignment.
	 */
	protected void gibbsLDA() {

		// Cursors.
		short k; // Topic [K]
		int j; // User [M]
		int r; // Item [V]
		int s; // Item [V]

		Action[] obsForUser;

		for (j = 0; j < nUsers; ++j) {
			obsForUser = data.getActionsForUser(userSet[j]);
			counterOfItemsPerUserProfile[j] = obsForUser.length;

			// The previous item of the first one is epsilon.
			r = nItems;
			int listIndex = 0;
			for (Action po : obsForUser) {
				s = itemIdToIndex.get(po.getItemId());
				k = topicAssignments[j].get(listIndex);
				k = sampleTopicViaFullConditionalProbability(j, r, s, k);
				topicAssignments[j].set(listIndex, Short.valueOf(k));
				r = s;
				++listIndex;
			}
		}
	}

	/**
	 * Initialized model parameters and counters, assigning a random (equally
	 * distributed) topic to each observation.
	 */
	@SuppressWarnings("unchecked")
	public void initializeModelParameters(PreferenceDataHandler preferenceData) {

		// Data information and indexes.
		data = preferenceData;
		nRatingsTraining = data.getSize();

		nUsers = preferenceData.getNUsers();
		nItems = preferenceData.getNItems();

		userSet = toIntArray(preferenceData.getUserSet());

		userIdToIndex = preferenceData.getUserIndex();
		itemIdToIndex = preferenceData.getItemIndex();

		// Cursors.
		short k; // Topic [K]
		int j; // User [M]
		int r; // Item [V]
		int s; // Item [V]

		// Initialize count variables.
		counterOfItemsPerUserProfileAndTopics = new int[nUsers][nTopics];
		counterOfItemsPerUserProfile = new int[nUsers];
		counterOfTopicAssignements = new int[nTopics][nItems + 1];
		counterOfTopicAssignementsToPairsOfItems = new SparseObjectMatrix2D[nTopics];

		for (k = 0; k < nTopics; ++k) {
			int tmp = (int) (nItems * Math.log(nItems));
			counterOfTopicAssignementsToPairsOfItems[k] = new SparseObjectMatrix2D(
					nItems + 1, nItems, tmp, 0.25, 0.5);
			// counterOfTopicAssignementsToPairsOfItems[k] = new
			// SparseObjectMatrix2D(nItems + 1, nItems, nItems*Math.log(nItems),
			// 0.25, 0.5);
		}
		// Topics are are initialised to values in [1,K] to determine the
		// initial state of the Markov chain.
		// topicAssignments = new SparseObjectMatrix2D(nUsers, nItems);

		topicAssignments = new LinkedList[nUsers];

		Integer tmp;
		Action[] obsForUser;

		// Update counters.
		for (j = 0; j < nUsers; ++j) {
			topicAssignments[j] = new LinkedList<Short>();
			obsForUser = data.getActionsForUser(userSet[j]);
			counterOfItemsPerUserProfile[j] = obsForUser.length;

			// The previous item of the first one is epsilon.
			r = nItems;
			int listIndex = 0;
			for (Action po : obsForUser) {
				s = itemIdToIndex.get(po.getItemId());
				k = (short) rand.nextInt(nTopics);

				topicAssignments[j].add(listIndex, Short.valueOf(k));
				++counterOfItemsPerUserProfileAndTopics[j][k];
				++counterOfTopicAssignements[k][r];

				tmp = (Integer) counterOfTopicAssignementsToPairsOfItems[k]
						.get(r, s);
				counterOfTopicAssignementsToPairsOfItems[k].set(r, s,
						tmp == null ? Integer.valueOf(1) : Integer
								.valueOf(tmp + 1));

				r = s;
				++listIndex;
			}
		}

		/*
		 * Initialize hyperparameters. ***
		 */

		// Initialize alpha.
		alpha = new double[nTopics];
		Arrays.fill(alpha, symmetricAlpha);
		alphaSum = nTopics * symmetricAlpha;

		// Each beta is equal to betaSymmetric.

		/*
		 * Initialize multinomial parameters. ***
		 */

		// Initialize theta.
		theta = new double[nUsers][nTopics];
		sumTheta = new double[nUsers][nTopics];

		// Initialize phi.
		phi = new double[nTopics][nItems + 1][nItems];
		sumPhi = new double[nTopics][nItems + 1][nItems];
	}

	/**
	 * Initializes the parameters of the algorithm.
	 * 
	 * @param preferenceData
	 *            Training data handler.
	 * @param configFile
	 *            Configuration file.
	 * 
	 * @throws IOException
	 *             Thrown if the <code>configFile</code> is corrupted.
	 * @throws FileNotFoundException
	 *             Thrown if the <code>configFile</code> does not exist.
	 */
	protected void readConfigurationParameters(String configFile)
			throws IOException, FileNotFoundException {

		Properties properties = new Properties();
		properties.load(new FileInputStream(configFile));

		// nTopics = Integer.parseInt(properties.getProperty("n_topics"));
		symmetricAlpha = Double.parseDouble(properties.getProperty("alpha"));
		symmetricBeta = Double.parseDouble(properties.getProperty("beta"));
		maxIterations = Integer.parseInt(properties
				.getProperty("n_max_iterations"));
		burnIn = Integer.parseInt(properties.getProperty("burn_in"));
		sampleLag = Integer.parseInt(properties.getProperty("sample_lag"));
		rand = new Random(Long.parseLong(properties.getProperty("random_seed")));

		updateHyperParams = false;
		if (properties.getProperty("update_alpha").equalsIgnoreCase("true"))
			updateHyperParams = true;

		String s = properties.getProperty("n_max_iterations_alpha_update");
		if (s != null)
			maxAlphaUpdateIterations = Integer.parseInt(s);

		// this.output = properties.getProperty("output");

		checkParameters(output);

	}

	/**
	 * Main method: Select initial state. Repeat a large number of times:
	 * 1.Select an element 2. Update conditional on other elements. If
	 * appropriate, output summary for each run.
	 * 
	 * @param preferenceData
	 *            Training data handler.
	 * @param configFile
	 *            Configuration file.
	 * @throws Exception
	 */
	public TokenBigramModel runInference(PreferenceDataHandler preferenceData,
			String configFile) throws Exception {

		// Read configuration parameters.
		String outputFileName = output;
		readConfigurationParameters(configFile);

		// Start chronometer.
		long initialTime = System.currentTimeMillis();

		// Initial parameters and counters of the model.
		initializeModelParameters(preferenceData);
		estimateMultinomialParametersAndStatistics(0);
		System.out.println("After initialization log-likelihood: " + llk);
		System.out.println("After initialization perplexity: " + perplexity);

		// Burn-in period.
		burnIn();

		// Sampling.
		boolean areMultinomialParamtersUpToDate = sampling();

		if (!areMultinomialParamtersUpToDate) {
			estimateMultinomialParametersAndStatistics(++sampleLagIterations);
			System.out.println("After burn-in log-likelihood: " + llk);
			System.out.println("After burn-in perplexity: " + perplexity);
		}

		System.out.println("Learning Time \t"
				+ (System.currentTimeMillis() - initialTime));

		return buildModel(outputFileName);
	}

	/**
	 * Sample the new topic of an item pair for the a user, computing the new
	 * topic's probability given the others topics and items.
	 * 
	 * @param j
	 *            User.
	 * @param r
	 *            Previous item.
	 * @param s
	 *            Current item.
	 * @param k
	 *            Topic currently assigned to <code>s</code> in profile of
	 *            <code>j</code>.
	 * @return The new topic assigned to the input item pair and user.
	 */
	protected short sampleTopicViaFullConditionalProbability(int j, int r,
			int s, short topic) {
		short k; // generic topic
		double[] p; // topic probability distribution

		double n1; // first part of the numerator of the likelihood formula
		double n2; // second part of the numerator of the likelihood formula
		double d; // denominator of the likelihood formula

		Integer tempInteger; // temporary variable

		// Decrementing counters.
		--counterOfItemsPerUserProfileAndTopics[j][topic];
		--counterOfTopicAssignements[topic][r];

		tempInteger = (Integer) counterOfTopicAssignementsToPairsOfItems[topic]
				.get(r, s);
		counterOfTopicAssignementsToPairsOfItems[topic].set(r, s, Integer
				.valueOf(tempInteger - 1));

		/*
		 * Compute p(z_mn). ***
		 */

		// Quasi probability distribution.
		p = new double[nTopics];

		for (k = 0; k < nTopics; ++k) {

			// Compute n1.
			n1 = counterOfItemsPerUserProfileAndTopics[j][k] + alpha[k];

			// Compute n2.
			tempInteger = (Integer) counterOfTopicAssignementsToPairsOfItems[k]
					.get(r, s);

			if (tempInteger == null)
				tempInteger = 0;

			n2 = tempInteger + symmetricBeta;

			// Compute d.
			d = counterOfTopicAssignements[k][r] + nItems * symmetricBeta;

			// Compute p[k].
			p[k] = n1 * n2 / d;
		}

		/*
		 * Sample the newTopic. ***
		 */

		for (k = 1; k < p.length; ++k)
			p[k] += p[k - 1];

		// Scaled sample because of unnormalised p[].
		double cumulative = rand.nextDouble() * p[nTopics - 1];

		for (topic = 0; topic < p.length; ++topic)
			if (cumulative < p[topic])
				break;

		// Incrementing counters.
		++counterOfItemsPerUserProfileAndTopics[j][topic];
		++counterOfTopicAssignements[topic][r];

		tempInteger = (Integer) counterOfTopicAssignementsToPairsOfItems[topic]
				.get(r, s);
		counterOfTopicAssignementsToPairsOfItems[topic].set(r, s,
				tempInteger == null ? Integer.valueOf(1) : Integer
						.valueOf(tempInteger + 1));

		/*
		 * return the best topic for the observation **
		 */
		return topic;
	}

	/**
	 * Runs the sampling procedure after the burn-in period.
	 * 
	 * @return A boolean that indicates if the multinomial parameters are up to
	 *         date.
	 */
	protected boolean sampling() {
		boolean converged = false;
		int iteration;
		int limit = maxIterations - burnIn;

		estimateMultinomialParametersAndStatistics(0);
		System.out.println("After burn-in log-likelihood: " + llk);
		System.out.println("After burn-in perplexity: " + perplexity);

		double percent;
		double oldPercent;

		System.out.println("Starting sampling.");
		oldPercent = 0;

		for (iteration = 0; !converged && iteration < limit; ++iteration) {
			percent = (double) iteration / limit;

			if (percent > oldPercent + 0.1)
				oldPercent = percent;

			gibbsLDA();

			if (updateHyperParams)
				updateAlpha();

			if ((iteration + 1) % sampleLag == 0) {
				estimateMultinomialParametersAndStatistics(++sampleLagIterations);
				System.out.print("In sampling Iteration \t" + iteration);
			}
		}

		System.out.println("Sampling: 100.0% complete");

		return limit == 0 || converged || iteration % sampleLag == 0;
	}

	public void setnTopics(int nTopics) {
		this.nTopics = nTopics;
	}

	/**
	 * Update the alpha Dirichlet parameter, user-topic associations.
	 */
	protected void updateAlpha() {

		// Cursors.
		int j; // user
		int k; // topic

		double[] previousAlpha = new double[nTopics];
		double num, den;

		// Repeat until alpha has not converged.
		int numIterazioni = 0;

		do {
			if (numIterazioni < maxAlphaUpdateIterations)
				break;
			System.arraycopy(alpha, 0, previousAlpha, 0, nTopics);

			den = -nUsers * digamma(alphaSum);

			for (j = 0; j < nUsers; ++j)
				den += digamma(counterOfItemsPerUserProfile[j] + alphaSum);

			for (k = 0; k < nTopics; k++) {
				num = -nUsers * digamma(alpha[k]);

				for (j = 0; j < nUsers; ++j)
					num += digamma(counterOfItemsPerUserProfileAndTopics[j][k]
							+ alpha[k]);

				alphaSum -= alpha[k];
				alpha[k] = alpha[k] * num / den;
				alphaSum += alpha[k];
			}
			numIterazioni++;

		} while (!ArrayUtilities.arrayConverged(alpha, previousAlpha, Math.pow(
				10, -6)));
	}
}