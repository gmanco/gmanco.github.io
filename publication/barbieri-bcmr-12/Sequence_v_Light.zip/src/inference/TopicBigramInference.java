/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package inference;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Random;

import model.TopicBigramModel;
import core.data.Action;
import core.data.PreferenceDataHandler;
import core.io.IOManager;
import core.util.ArrayUtilities;

/**
 * This class infers a LDA model parameters, with the assumption that each item
 * depends on its topic and the topic assigned to the previous item in the
 * sequence.
 * 
 * @author Ettore Ritacco
 * @version 2.0.0
 */
public class TopicBigramInference {

	public static boolean debug = true;

	/**
	 * Main program for testing purpose.
	 * 
	 * @param args
	 *            Empty
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 5) {
			printUsage();
			return;
		}

		if (debug)
			System.out.println("Topic Bigram Inference");

		PreferenceDataHandler data = new PreferenceDataHandler();
		data.read(args[0], args[1]);
		data.getInfo();

		TopicBigramInference inf = new TopicBigramInference();

		int nTopics = Integer.parseInt(args[2]);
		String output = args[3];
		inf.nTopics = nTopics;
		inf.output = output;

		if (debug) {
			System.out.println("N topics\t" + nTopics);
			System.out.println("Output \t" + output);
		}

		inf.runInference(data, args[4]);
	}

	private static boolean matrixConverged(double[][] a, double[][] b,
			double threshold) {
		double a2sum = 0;
		double difference2 = 0;

		for (int i = 0; i < a.length; i++)
			for (int j = 0; j < a[0].length; j++) {
				a2sum += a[i][j] * a[i][j];
				difference2 += (a[i][j] - b[i][j]) * (a[i][j] - b[i][j]);
			}

		return Math.sqrt(difference2 / a2sum) < threshold;
	}

	public static double[][] matrixCopy(double[][] m) {
		double[][] m1 = new double[m.length][m[0].length];
		for (int i = 0; i < m.length; i++)
			for (int j = 0; j < m[0].length; j++)
				m1[i][j] = m[i][j];
		return m1;
	}

	/**
	 * Return a string representation of a real number with a specific number of
	 * decimal digits.
	 * 
	 * @param d
	 *            Number to convert in <code>{@link java.lang.String}</code>.
	 * @param i
	 *            Number of decimal digits to dislpay.
	 * @return A string representation of <code>d</code> with <code>i</code>
	 *         decimal digits
	 */
	private static String padd(double d, int i) {
		long pow = Math.round(Math.pow(10, i));

		d *= pow;
		d = (double) Math.round(d) / pow;

		return String.valueOf(d);
	}

	public static void printUsage() {
		System.out.println("Topic Bigram Inference");
		System.out.println("<training> <readConf> <nTopics> <output> <params>");
	}

	/**
	 * Convert a collection of <code>{@link java.lang.Integer}</code> values
	 * into an array of <code>int</code>.
	 * 
	 * @param c
	 *            Collection of <code>{@link java.lang.Integer}</code> values.
	 * @return an array of <code>int</code>.
	 */
	protected static int[] toIntArray(Collection<Integer> c) {
		int[] ret = new int[c.size()];
		int i = 0;

		for (Integer value : c)
			ret[i++] = value;

		return ret;
	}

	/**
	 * Dirichlet parameter, user-topic associations.
	 */
	protected double[][] alpha; // [K+1][K]

	/**
	 * Simplified version of the Dirichlet parameter alpha vector: user-topic
	 * associations.
	 */
	protected double symmetricAlpha;

	/**
	 * Cumulative statistics of alpha.
	 */
	protected double[] sumAlpha;
	/**
	 * Simplified version of the Dirichlet parameter beta matrix: topic-itemPair
	 * associations.
	 */
	protected double symmetricBeta;
	/**
	 * Burn-in period.
	 */
	protected int burnIn = 100;
	/**
	 * Training data handler.
	 */
	protected PreferenceDataHandler data;

	/**
	 * Map<key: item id, value: item index in the inner format>.
	 */
	protected Int2IntOpenHashMap itemIdToIndex;
	/**
	 * Max number of iterations.
	 */
	protected int maxIterations = 1000;
	/**
	 * Number of distinct items.
	 */
	protected int nItems; // V
	/**
	 * Training data size.
	 */
	protected int training_size;
	/**
	 * Number of topics.
	 */
	protected int nTopics; // K
	/**
	 * Number of distinct users.
	 */
	protected int nUsers; // M
	/**
	 * Multinomial parameters Phi.
	 */
	protected double[][] phi; // [K][V], (k, r)

	/**
	 * Multinomial parameters Phi.
	 */
	protected double[][] sumPhi; // [K][V], (k, r)

	/**
	 * Random number generator.
	 */
	protected Random rand;

	/**
	 * Sample lag.
	 */
	protected int sampleLag = 10;

	/**
	 * Multinomial parameters Theta.
	 */
	protected double[][][] theta; // [M][K][K]
	/**
	 * Multinomial parameters Theta.
	 */
	protected double[][][] sumTheta; // [M][K+1][K]
	/**
	 * Topic assignments for each pair (user, item).
	 */
	protected short[][] topicAssignments; // [SUM(Nd for each d)][K]
	protected boolean updateHyperParams = true;
	/**
	 * Map<key: user id, value: user index in the inner format>.
	 */
	protected Int2IntOpenHashMap userIdToIndex;

	/**
	 * Map<kefy: user index in the inner format, value: user id>.
	 */
	protected int[] userSet;

	/**
	 * Log-likelihood of the estimated model
	 */
	protected double llk;

	/**
	 * Perplexity of the estimated model
	 */
	protected double perplexity;

	protected int sampleIteration;
	// counters
	/*
	 * Counter: number of times that the word has been assigned to the topic
	 */
	protected int[][] n_topic_word; // K x N

	protected int[] count_topic; // K
	/**
	 * Counter: number of item in the user profile j.
	 */
	protected int[] counterOfItemsPerUser; // [M]

	/**
	 * Counter: number times transition k->k1 for the user u
	 */
	protected int[][][] n_u_k_k1; // M x (K) x K

	protected int[][] n_u_k_k1_sum; // M x (K)

	protected int maxAlphaUpdateIterations = 10;

	protected String output;

	protected int updateAlphaIterations;

	public static boolean store = true;

	protected double[] probs;

	/**
	 * Builds a <code>latentFactorModels.SEQ1_Model</code> object whose
	 * parameters are computed via the inference.
	 * 
	 * @param output
	 *            Output File Log.
	 * @return The <code>latentFactorModels.SEQ1_Model</code> object
	 * 
	 * @throws Exception
	 *             Thrown if <code>output</code> file does not exist.
	 */
	protected TopicBigramModel buildModel() throws Exception {
		TopicBigramModel seq = new TopicBigramModel(nTopics);
		seq.setAlpha(alpha);
		double[] beta = new double[nItems];
		Arrays.fill(beta, symmetricBeta);
		seq.setBeta(beta);
		seq.setItemIdToIndex(itemIdToIndex);
		seq.setPhi(phi);
		seq.setTheta(theta);
		seq.setUserIdToIndex(userIdToIndex);
		seq.setTopicsAssignments(topicAssignments);

		if (store)
			IOManager.writeObjectOnFile(seq, output);

		return seq;
	}

	/**
	 * Runs the burn-in period for the inferecen.
	 */
	protected void burnIn() {
		int iteration;
		double percent;
		double oldPercent;

		if (debug)
			System.out.println("Starting burn-in.");

		oldPercent = 0;

		for (iteration = 0; iteration < burnIn; ++iteration) {
			percent = (double) iteration / burnIn;

			if (debug)
				if (percent >= oldPercent + 0.1) {
					System.out.println("Burn-in: " + padd(percent * 100, 1)
							+ "%");
					oldPercent = percent;
				}

			gibbsLDA();

			if (updateHyperParams)
				updateAlpha(++updateAlphaIterations);
		}

		if (debug)
			System.out.println("Burn-in: 100.0% complete");
	}

	/**
	 * Check if input parameters are valid.
	 * 
	 * @param output
	 *            Output file name.
	 */
	private void checkParameters() {

		if (debug) {
			System.out.println("Params");
			System.out.println("N_Topics\t" + nTopics);
			System.out.println("Alpha\t" + symmetricAlpha);
			System.out.println("Beta\t" + symmetricBeta);
			System.out.println("N_Max_Iterations\t" + maxIterations);
			System.out.println("Burn in\t" + burnIn);
			System.out.println("Sample Lag\t" + sampleLag);
			System.out.println("Update Alpha\t" + updateHyperParams);
			System.out.println("Output\t" + output);
		}

		if (nTopics <= 0)
			throw new IllegalArgumentException(
					"The number of topics must be a non-negative integer.");

		if (symmetricAlpha <= 0)
			throw new IllegalArgumentException(
					"The symmetric Alpha parameter must be a non-negative real.");

		if (symmetricBeta <= 0)
			throw new IllegalArgumentException(
					"The symmetric Beta parameter must be a non-negative real.");

		if (maxIterations <= 0 || burnIn >= maxIterations)
			throw new IllegalArgumentException(
					"The maximum number of iteration"
							+ " must be a non-negative integer and greater"
							+ " than the burn-in's number of iteration.");

		if (burnIn <= 0)
			throw new IllegalArgumentException("The burn-in's number "
					+ "of iteration must be a non-negative integer.");

		if (sampleLag <= 0 || sampleLag >= maxIterations - burnIn)
			throw new IllegalArgumentException("The sample lag must be a "
					+ "non-negative integer and less than the"
					+ " difference between maxIterations and burnIn.");

		if (store)
			try {
				File f = new File(output);
				if (!f.exists())
					if (!f.createNewFile())
						throw new IllegalArgumentException(
								"Output file does not exist or invalid.");

			} catch (IOException e) {
				throw new IllegalArgumentException(
						"Output file does not exist or invalid.", e);
			}
	}

	protected double computeGammaSum(final int u, final int[] observationForUser) {
		int i, k, h;
		double[] oldGamma = new double[nTopics];
		double[] newGamma = new double[nTopics];

		for (k = 0; k < nTopics; ++k)
			newGamma[k] = oldGamma[k] = phi[k][observationForUser[0]];

		for (i = 1; i < observationForUser.length; ++i) {
			for (k = 0; k < nTopics; ++k) {
				newGamma[k] = 0;

				for (h = 0; h < nTopics; ++h)
					newGamma[k] += oldGamma[h] * theta[u][h][k];

				newGamma[k] *= phi[k][observationForUser[i]];
			}

			System.arraycopy(newGamma, 0, oldGamma, 0, newGamma.length);
		}

		return ArrayUtilities.sum(newGamma);
	}

	/**
	 * Computes the log-likelihood of the model.
	 * 
	 * @return The log-likelihood.
	 */
	public double computeLogLikelihood() {
		double llk = 0d;
		final int[] userSet = toIntArray(data.getUserSet());
		double d;
		LinkedList<String> listErrs = new LinkedList<String>();

		for (int u = 0; u < userSet.length; ++u) {
			d = Math.log(computeGammaSum(u, convert2index(data
					.getActionsForUser(userSet[u]))));

			if (!Double.isInfinite(d) && !Double.isNaN(d))
				llk += d;
			else
				listErrs.add("(Index:" + u + ", id:" + userSet[u] + ")");
		}

		if (listErrs.size() > 0)
			System.out.println("Warning #" + listErrs.size() + ": " + listErrs);

		return llk;
	}

	/**
	 * Computes the perplexity of the model.
	 * 
	 * @return The perplexity.
	 */
	protected double computePerplexity(double llk) {
		return Math.exp(-llk / data.getSize());
	}

	/**
	 * Computes estimated topic-item associations.
	 */
	protected void computePhi(int sampleIteration) {
		int k; // Topic.
		int r; // Item.
		double den;

		if (sampleIteration == 0)
			for (k = 0; k < nTopics; ++k) {
				den = nItems * symmetricBeta + count_topic[k];

				for (r = 0; r < nItems; ++r)
					phi[k][r] = (n_topic_word[k][r] + symmetricBeta) / den;
			}
		else {
			double newPhi;

			for (k = 0; k < nTopics; ++k) {
				den = nItems * symmetricBeta + count_topic[k];

				for (r = 0; r < nItems; ++r) {
					newPhi = (n_topic_word[k][r] + symmetricBeta) / den;
					sumPhi[k][r] += newPhi;
					phi[k][r] = sumPhi[k][r] / sampleIteration;
				}
			}
		}
	}

	/**
	 * Computes estimated user-topic associations.
	 */
	protected void computeTheta(int sampleIteration) {
		int d;
		int kStar;
		int kMinus;
		double den;

		if (sampleIteration == 0)
			for (d = 0; d < nUsers; ++d)
				for (kMinus = 0; kMinus < nTopics; ++kMinus) {
					den = n_u_k_k1_sum[d][kMinus] + sumAlpha[kMinus];

					for (kStar = 0; kStar < nTopics; ++kStar)
						theta[d][kMinus][kStar] = (n_u_k_k1[d][kMinus][kStar] + alpha[kMinus][kStar])
								/ den;
				}
		else {
			double newTheta;

			for (d = 0; d < nUsers; ++d)
				for (kMinus = 0; kMinus < nTopics; ++kMinus) {
					den = n_u_k_k1_sum[d][kMinus] + sumAlpha[kMinus];

					for (kStar = 0; kStar < nTopics; ++kStar) {
						newTheta = (n_u_k_k1[d][kMinus][kStar] + alpha[kMinus][kStar])
								/ den;

						sumTheta[d][kMinus][kStar] += newTheta;
						theta[d][kMinus][kStar] = sumTheta[d][kMinus][kStar]
								/ sampleIteration;
					}
				}
		}
	}

	private int[] convert2index(Action[] actions) {
		int[] ret = new int[actions.length];

		for (int i = 0, n = actions.length; i < n; ++i)
			ret[i] = itemIdToIndex.get(actions[i].getItemId());

		return ret;
	}

	/**
	 * Estimates the multinomial parameters (Theta, Phi) and the log-likelihood
	 * and perplexity of the model.
	 */
	protected void estimateMultinomialParameters(int sampleIteration) {
		computeTheta(sampleIteration);
		computePhi(sampleIteration);
	}

	public double[][] getAlpha() {
		return alpha;
	}

	public int[] getCount_topic() {
		return count_topic;
	}

	public int[][] getN_topic_word() {
		return n_topic_word;
	}

	public int getnTopics() {
		return nTopics;
	}

	public double[][] getPhi() {
		return phi;
	}

	public double getSymmetricBeta() {
		return symmetricBeta;
	}

	/**
	 * Runs the Gibbs sampling procedure for each topic assignment.
	 */
	protected void gibbsLDA() {

		// Cursors.
		short kMinus; // Topic [K]
		short kStar; // Topic [K]
		short kPlus; // Topic
		int u; // User [M]
		int currentItem; // Item

		Action[] obsForUser;
		Action po;
		for (u = 0; u < nUsers; ++u) {
			currentItem = -1;
			obsForUser = data.getActionsForUser(userSet[u]);
			kMinus = -1;
			kStar = -1;
			for (int j = 0; j < obsForUser.length; j++) {
				po = obsForUser[j];
				currentItem = itemIdToIndex.get(po.getItemId());

				if (j == 0) {
					kStar = topicAssignments[u][0];
					kPlus = topicAssignments[u][1];
					kStar = sampleTopicFirstItem(u, currentItem, kStar, kPlus);
					topicAssignments[u][0] = kStar;
				}// first item

				else if (j == obsForUser.length - 1) {
					kMinus = topicAssignments[u][j - 1];
					kStar = topicAssignments[u][j];
					kStar = sampleTopicLastItem(u, currentItem, kMinus, kStar);
					topicAssignments[u][j] = kStar;
				}// last item
				else {// full sequence is available
					kMinus = topicAssignments[u][j - 1];
					kPlus = topicAssignments[u][j + 1];
					kStar = topicAssignments[u][j];

					kStar = sampleTopicViaFullConditionalProbability(u,
							currentItem, kMinus, kStar, kPlus);
					topicAssignments[u][j] = kStar;

				}//

			}

		}
	}// gibbsLDA

	/**
	 * Initialized model parameters and counters, assigning a random (equally
	 * distributed) topic to each observation.
	 */
	public void initializeModelParameters(PreferenceDataHandler preferenceData) {

		// Data information and indexes.
		data = preferenceData;
		training_size = data.getSize();

		nUsers = preferenceData.getNUsers();
		nItems = preferenceData.getNItems();

		userSet = toIntArray(preferenceData.getUserSet());

		userIdToIndex = preferenceData.getUserIndex();
		itemIdToIndex = preferenceData.getItemIndex();

		// Cursors.
		short kMinus; // Topic [K]
		short kStar; // Topic [K]
		int u; // User [M]
		int v; // Item [V]

		// Initialize count variables.
		n_topic_word = new int[nTopics][nItems];

		count_topic = new int[nTopics];

		counterOfItemsPerUser = new int[nUsers];

		n_u_k_k1 = new int[nUsers][nTopics][nTopics];
		n_u_k_k1_sum = new int[nUsers][nTopics];

		// Topics are are initialised to values in [1,K] to determine the
		// initial state of the Markov chain.
		topicAssignments = new short[nUsers][];

		Action[] obsForUser;
		Action po;

		// Update counters.
		for (u = 0; u < nUsers; ++u) {
			obsForUser = data.getActionsForUser(userSet[u]);
			topicAssignments[u] = new short[obsForUser.length];
			counterOfItemsPerUser[u] = obsForUser.length;
			kMinus = (short) rand.nextInt(nTopics);

			for (int j = 0; j < obsForUser.length; j++) {
				po = obsForUser[j];
				v = itemIdToIndex.get(po.getItemId());
				kStar = (short) rand.nextInt(nTopics);

				topicAssignments[u][j] = kStar;

				if (j > 0) {
					++n_u_k_k1[u][kMinus][kStar];
					++n_u_k_k1_sum[u][kMinus];
				}

				++n_topic_word[kStar][v];
				++count_topic[kStar];

				kMinus = kStar;
			}
		}

		/*
		 * Initialize hyperparameters. ***
		 */

		// Initialize alpha.
		alpha = new double[nTopics][nTopics];
		for (int c1 = 0; c1 < alpha.length; c1++)
			for (int c2 = 0; c2 < alpha[0].length; c2++)
				alpha[c1][c2] = symmetricAlpha;

		sumAlpha = new double[nTopics];
		Arrays.fill(sumAlpha, nTopics * symmetricAlpha);

		// Each beta is equal to betaSymmetric.

		/*
		 * Initialize multinomial parameters. ***
		 */

		// Initialize theta.
		theta = new double[nUsers][nTopics][nTopics];
		sumTheta = new double[nUsers][nTopics][nTopics];

		// Initialize phi.
		phi = new double[nTopics][nItems];
		sumPhi = new double[nTopics][nItems];

		updateAlphaIterations = 1;
	}

	/**
	 * Initializes the parameters of the algorithm.
	 * 
	 * @param preferenceData
	 *            Training data handler.
	 * @param configFile
	 *            Configuration file.
	 * 
	 * @throws IOException
	 *             Thrown if the <code>configFile</code> is corrupted.
	 * @throws FileNotFoundException
	 *             Thrown if the <code>configFile</code> does not exist.
	 */
	protected void readConfigurationParameters(String configFile)
			throws IOException, FileNotFoundException {

		Properties properties = new Properties();
		properties.load(new FileInputStream(configFile));

		// nTopics = Integer.parseInt(properties.getProperty("n_topics"));
		symmetricAlpha = Double.parseDouble(properties.getProperty("alpha"));
		symmetricBeta = Double.parseDouble(properties.getProperty("beta"));
		maxIterations = Integer.parseInt(properties
				.getProperty("n_max_iterations"));
		burnIn = Integer.parseInt(properties.getProperty("burn_in"));
		sampleLag = Integer.parseInt(properties.getProperty("sample_lag"));
		rand = new Random(Long.parseLong(properties.getProperty("random_seed")));

		updateHyperParams = false;
		if (properties.getProperty("update_alpha").equalsIgnoreCase("true"))
			updateHyperParams = true;

		String s = properties.getProperty("n_max_iterations_alpha_update");
		if (s != null)
			maxAlphaUpdateIterations = Integer.parseInt(s);

		// this.output = properties.getProperty("output");

		checkParameters();

	}

	/**
	 * Main method: Select initial state. Repeat a large number of times:
	 * 1.Select an element 2. Update conditional on other elements. If
	 * appropriate, output summary for each run.
	 * 
	 * @param preferenceData
	 *            Training data handler.
	 * @param configFile
	 *            Configuration file.
	 * @throws Exception
	 */
	public TopicBigramModel runInference(PreferenceDataHandler preferenceData,
			String configFile) throws Exception {
		System.out.println("Class: " + getClass().getCanonicalName());

		// Read configuration parameters.
		readConfigurationParameters(configFile);

		// Start chronometer.
		long initialTime = System.currentTimeMillis();

		// Initial parameters and counters of the model.
		initializeModelParameters(preferenceData);

		// Burn-in period.
		burnIn();

		// Sampling.
		boolean areMultinomialParamtersUpToDate = sampling();

		if (!areMultinomialParamtersUpToDate)
			estimateMultinomialParameters(++sampleIteration);

		System.out.println("Learning Time \t"
				+ (System.currentTimeMillis() - initialTime));

		return buildModel();
	}

	protected short sampleTopicFirstItem(int user, int firstItem, short kStar,
			short kPlus) {

		short k;
		double n2;
		double n3;
		double d3;

		// Decrementing counters.
		--n_u_k_k1[user][kStar][kPlus];
		--n_topic_word[kStar][firstItem];
		--count_topic[kStar];

		if (n_topic_word[kStar][firstItem] < 0 || count_topic[kStar] < 0
				|| n_u_k_k1[user][kStar][kPlus] < 0)
			throw new RuntimeException("Errore contatori negativi");

		/*
		 * Compute p(z_mn). ***
		 */

		if (probs == null)
			probs = new double[nTopics];

		for (k = 0; k < nTopics; ++k) {
			n2 = n_u_k_k1[user][k][kPlus] + alpha[k][kPlus];
			n3 = n_topic_word[k][firstItem] + symmetricBeta;
			d3 = count_topic[k] + nItems * symmetricBeta;

			probs[k] = n2 * n3 / d3;

		}

		/*
		 * Sample the newTopic. ***
		 */

		for (k = 1; k < probs.length; ++k)
			probs[k] += probs[k - 1];

		// Scaled sample because of unnormalised p[].
		double cumulative = rand.nextDouble() * probs[nTopics - 1];

		for (kStar = 0; kStar < probs.length; ++kStar)
			if (cumulative <= probs[kStar])
				break;

		// Incrementing counters.
		++n_u_k_k1[user][kStar][kPlus];
		++n_topic_word[kStar][firstItem];
		++count_topic[kStar];

		/*
		 * return the best topic for the observation **
		 */
		return kStar;

	}

	protected short sampleTopicLastItem(int user, int currentItem,
			short kMinus, short kStar) {

		short k; // generic topic

		double n1;
		double n3;
		double d3;

		// Decrementing counters.
		--n_u_k_k1[user][kMinus][kStar];
		--n_topic_word[kStar][currentItem];
		--count_topic[kStar];

		if (n_topic_word[kStar][currentItem] < 0 || count_topic[kStar] < 0
				|| n_u_k_k1[user][kMinus][kStar] < 0)
			throw new RuntimeException("Errore contatori negativi");

		/*
		 * Compute p(z_mn). ***
		 */

		if (probs == null)
			probs = new double[nTopics];

		for (k = 0; k < nTopics; ++k) {
			n1 = n_u_k_k1[user][kMinus][k] + alpha[kMinus][k];
			n3 = n_topic_word[k][currentItem] + symmetricBeta;
			d3 = count_topic[k] + nItems * symmetricBeta;

			probs[k] = n1 * n3 / d3;
		}

		/*
		 * Sample the newTopic. ***
		 */

		for (k = 1; k < probs.length; ++k)
			probs[k] += probs[k - 1];

		// Scaled sample because of unnormalised p[].
		double cumulative = rand.nextDouble() * probs[nTopics - 1];

		for (kStar = 0; kStar < probs.length; ++kStar)
			if (cumulative <= probs[kStar])
				break;

		// Incrementing counters.
		++n_u_k_k1[user][kMinus][kStar];
		++n_topic_word[kStar][currentItem];
		++count_topic[kStar];

		/*
		 * return the best topic for the observation **
		 */
		return kStar;
	}

	/**
	 * Sample the new topic of an item pair for the a user, computing the new
	 * topic's probability given the others topics and items.
	 * 
	 * @return The new topic assigned to the input item pair and user.
	 */
	protected short sampleTopicViaFullConditionalProbability(int user,
			int currentItem, short kMinus, short kStar, short kPlus) {

		short k; // generic topic

		double n1;
		double n2;
		double n3;
		double d3;

		// Decrementing counters.
		--n_u_k_k1[user][kMinus][kStar];
		--n_u_k_k1[user][kStar][kPlus];
		--count_topic[kStar];
		--n_topic_word[kStar][currentItem];
		--n_u_k_k1_sum[user][kStar];

		if (n_topic_word[kStar][currentItem] < 0 || count_topic[kStar] < 0
				|| n_u_k_k1[user][kMinus][kStar] < 0
				|| n_u_k_k1[user][kStar][kPlus] < 0)
			throw new RuntimeException("Errore contatori negativi");

		/*
		 * Compute p(z_mn). ***
		 */

		// Quasi probability distribution.
		if (probs == null)
			probs = new double[nTopics];

		for (k = 0; k < nTopics; ++k) {
			n1 = n_u_k_k1[user][kMinus][k] + alpha[kMinus][k];
			n2 = n_u_k_k1[user][k][kPlus] + alpha[k][kPlus];
			n3 = n_topic_word[k][currentItem] + symmetricBeta;
			d3 = count_topic[k] + nItems * symmetricBeta;

			probs[k] = n1 * n2 * n3 / d3;
		}

		/*
		 * Sample the newTopic. ***
		 */

		for (k = 1; k < probs.length; ++k)
			probs[k] += probs[k - 1];

		// Scaled sample because of unnormalised p[].
		double cumulative = rand.nextDouble() * probs[nTopics - 1];

		for (kStar = 0; kStar < probs.length; ++kStar)
			if (cumulative <= probs[kStar])
				break;

		// Incrementing counters.
		++n_u_k_k1[user][kMinus][kStar];
		++n_u_k_k1[user][kStar][kPlus];
		++n_topic_word[kStar][currentItem];
		++count_topic[kStar];
		++n_u_k_k1_sum[user][kStar];

		/*
		 * return the best topic for the observation **
		 */
		return kStar;
	}

	/**
	 * Runs the sampling procedure after the burn-in period.
	 * 
	 * @return A boolean that indicates if the multinomial parameters are up to
	 *         date.
	 */
	protected boolean sampling() {
		boolean converged = false;
		int iteration;
		int limit = maxIterations - burnIn;

		double percent;
		double oldPercent;

		if (debug)
			System.out.println("Starting sampling.");

		oldPercent = 0;

		for (iteration = 0; !converged && iteration < limit; ++iteration) {
			percent = (double) iteration / limit;

			if (debug)
				if (percent >= oldPercent + 0.1) {
					System.out.println("Sampling: " + padd(percent * 100, 1)
							+ "%");
					oldPercent = percent;
				}

			gibbsLDA();

			if (updateHyperParams)
				updateAlpha(++updateAlphaIterations);

			if ((iteration + 1) % sampleLag == 0)
				estimateMultinomialParameters(++sampleIteration);
		}

		if (debug)
			System.out.println("Sampling: 100.0% complete");

		return limit == 0 || converged || iteration % sampleLag == 0;
	}

	public void setnTopics(int nTopics) {
		this.nTopics = nTopics;
	}

	/**
	 * Update the alpha Dirichlet parameter, user-topic associations.
	 */
	protected void updateAlpha(int updateAlphaIterations) {
		int nIt = 0;

		double[][] previousAlpha = new double[nTopics][nTopics];

		do {
			for (int c1 = 0; c1 < nTopics; ++c1)
				System.arraycopy(alpha[c1], 0, previousAlpha[c1], 0, nTopics);

			updateAlpha1(updateAlphaIterations);
			nIt++;

		} while (!matrixConverged(alpha, previousAlpha, Math.pow(10, -2))
				&& nIt < maxAlphaUpdateIterations);
	}

	private void updateAlpha1(int updateAlphaIterations) {

		// Cursors.
		int d;
		int kStar, kMinus;
		int limitNum;
		int limitDen;
		int j, n;
		double num;
		double den;
		double newAlpha;

		for (kMinus = 0; kMinus < nTopics; ++kMinus)
			for (kStar = 0; kStar < nTopics; ++kStar) {
				num = 0;
				for (d = 0; d < nUsers; ++d) {
					limitNum = n_u_k_k1[d][kMinus][kStar];

					for (j = 0, n = limitNum; j < n; ++j)
						num += 1.0 / (j + alpha[kMinus][kStar]);
				}

				den = 0;
				for (d = 0; d < nUsers; ++d) {
					limitDen = n_u_k_k1_sum[d][kMinus];

					for (j = 0, n = limitDen; j < n; ++j)
						den += 1.0 / (j + sumAlpha[kMinus]);
				}

				newAlpha = Math.exp(Math.log(alpha[kMinus][kStar])
						+ Math.log(num) - Math.log(den));

				if (Double.isNaN(newAlpha) || Double.isInfinite(newAlpha)
						|| newAlpha < 0)
					newAlpha = 0;

				newAlpha = (alpha[kMinus][kStar] * (updateAlphaIterations - 1) + newAlpha)
						/ updateAlphaIterations;

				if (Double.isInfinite(sumAlpha[kMinus] + newAlpha
						- alpha[kMinus][kStar]))
					throw new RuntimeException("sumAlpha sballati");

				sumAlpha[kMinus] -= alpha[kMinus][kStar];
				alpha[kMinus][kStar] = newAlpha;
				sumAlpha[kMinus] += alpha[kMinus][kStar];

				if (alpha[kMinus][kStar] == 0)
					throw new RuntimeException();
			}
	}
}