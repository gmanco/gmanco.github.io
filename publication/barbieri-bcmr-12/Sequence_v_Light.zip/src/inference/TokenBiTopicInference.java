/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package inference;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Random;

import model.TokenBiTopicModel;
import cern.colt.matrix.impl.SparseObjectMatrix2D;
import core.data.Action;
import core.data.PreferenceDataHandler;
import core.io.IOManager;
import core.util.ArrayUtilities;

/**
 * This class infers a LDA model parameters, with the assumption that each item
 * depends on its topic and the previous item in the sequence.
 * 
 * @author Ettore Ritacco
 * @version 2.0.0
 */
public class TokenBiTopicInference {

	/**
	 * Estimates the Digamma value of a real positive number.
	 * 
	 * @param x
	 *            Input of the Digamma function.
	 * @return The Digamma value for <code>x</code>.
	 */
	public static double digamma(double x) {
		double p;
		assert x > 0;
		x = x + 6;
		p = 1 / (x * x);
		p = (((0.004166666666667 * p - 0.003968253986254) * p + 0.008333333333333)
				* p - 0.083333333333333)
				* p;
		p = p + Math.log(x) - 0.5 / x - 1 / (x - 1) - 1 / (x - 2) - 1 / (x - 3)
				- 1 / (x - 4) - 1 / (x - 5) - 1 / (x - 6);
		return p;
	}

	/**
	 * Main program for testing purpose.
	 * 
	 * @param args
	 *            Empty
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 5) {
			printUsage();
			return;
		}

		System.out.println("Token Bitopic  Inference");
		long start = System.currentTimeMillis();
		PreferenceDataHandler data = new PreferenceDataHandler();
		data.read(args[0], args[1]);
		data.getInfo();

		TokenBiTopicInference inf = new TokenBiTopicInference();
		int nTopics = Integer.parseInt(args[2]);
		String output = args[3];
		inf.nTopics = nTopics;
		inf.output = output;

		System.out.println("N topics\t" + nTopics);
		System.out.println("Output \t" + output);

		inf.runInference(data, args[4]);
		long end = System.currentTimeMillis();
		System.out.println("Building Time: " + (end - start));
	}

	private static String padd(double d, int i) {
		long pow = Math.round(Math.pow(10, i));

		d *= pow;
		d = (double) Math.round(d) / pow;

		return String.valueOf(d);
	}

	public static void printUsage() {
		System.out.println("Token Bitopic Bigram Inference");
		System.out.println("<training> <readConf> <nTopics> <output> <params>");
	}

	/**
	 * Convert a collection of <code>{@link java.lang.Integer}</code> values
	 * into an array of <code>int</code>.
	 * 
	 * @param c
	 *            Collection of <code>{@link java.lang.Integer}</code> values.
	 * @return an array of <code>int</code>.
	 */
	protected static int[] toIntArray(Collection<Integer> c) {
		int[] ret = new int[c.size()];
		int i = 0;

		for (Integer value : c)
			ret[i++] = value;

		return ret;
	}

	/**
	 * Dirichlet parameter, user-topic associations.
	 */
	protected double[] alpha; // [M]

	/**
	 * Simplified version of the Dirichlet parameter alpha vector: user-topic
	 * associations.
	 */
	private double symmetricAlpha;
	/**
	 * Cumulative statistics of alpha.
	 */
	protected double alphaSum;
	/**
	 * Simplified version of the Dirichlet parameter beta matrix: topic-itemPair
	 * associations.
	 */
	protected double symmetricBeta;
	/**
	 * Burn-in period.
	 */
	protected int burnIn = 100;
	/**
	 * Counter: number of item in the user profile j.
	 */
	protected int[] counterOfItemsPerUserProfile; // [M]
	/**
	 * Counter: number of item in the user profile j assigned to topic k.
	 */
	protected int[][] n_kStar; // [M][K]
	/**
	 * Topic assignments for each pair (user, item).
	 */
	protected LinkedList<Short>[] topicAssignments; // [SUM(Nd for each d)][K]
	/**
	 * Counter: number times that a item is assigned to a pair of topic.
	 */
	protected SparseObjectMatrix2D[] n_k1_k2;
	/**
	 * Total Counter: number times that each item is assigned to a pair of
	 * topic.
	 */
	protected SparseObjectMatrix2D sum_n_k1_k2;
	// [K][V + 1][V]
	// TODO da cambiare in mappe
	/**
	 * Training data handler.
	 */
	protected PreferenceDataHandler data;
	/**
	 * Map<key: item id, value: item index in the inner format>.
	 */
	protected Int2IntOpenHashMap itemIdToIndex;
	/**
	 * Max number of iterations.
	 */
	protected int maxIterations = 1000;
	/**
	 * Number of distinct items.
	 */
	protected int nItems; // V

	/**
	 * Number of topics.
	 */
	protected int nTopics; // K
	/**
	 * Number of distinct users.
	 */
	protected int nUsers; // M
	/**
	 * Support vector for the phi computation
	 */
	protected double[][][] sumPhi; // [K][V + 1][V], (k, r, s)
	/**
	 * Multinomial parameters Phi.
	 */
	protected double[][][] phi; // [K][V + 1][V], (k, r, s)
	/**
	 * Random number generator.
	 */
	protected Random rand;
	/**
	 * Sample lag.
	 */
	protected int sampleLag = 10;
	/**
	 * Multinomial parameters Theta.
	 */
	protected double[][] theta; // [M][K]
	// TODO da cambiare in mappe
	protected boolean updateHyperParams = true;
	/**
	 * Map<key: user id, value: user index in the inner format>.
	 */
	protected Int2IntOpenHashMap userIdToIndex;
	/**
	 * Map<key: user index in the inner format, value: user id>.
	 */
	protected int[] userSet;
	/**
	 * Log-likelihood of the estimated model
	 */
	private double llk;
	/**
	 * Perplexity of the estimated model
	 */
	private double perplexity;
	/**
	 * Support vector for the theta computation
	 */
	double[][] sumTheta; // [M][K]
	/**
	 * Number of multinomial parameter computation after the burn-in
	 */
	protected int sampleLagIterations;
	protected int maxAlphaUpdateIterations = 30;
	protected String output;

	public static boolean store = true;

	private int updateAlphaIterations;

	/**
	 * Builds a <code>latentFactorModels.Token_BiTopic_Model</code> object whose
	 * parameters are computed via the inference.
	 * 
	 * @param output
	 *            Output File Log.
	 * @return The <code>latentFactorModels.Token_BiTopic_Model</code> object
	 * 
	 * @throws Exception
	 *             Thrown if <code>output</code> file does not exist.
	 */
	protected TokenBiTopicModel buildModel(String output) throws Exception {
		TokenBiTopicModel seq = new TokenBiTopicModel(nTopics);
		seq.setAlpha(alpha);
		seq.setSymmetricBeta(symmetricBeta);
		seq.setItemIdToIndex(itemIdToIndex);
		seq.setPhi(phi);
		seq.setTheta(theta);
		seq.setUserIdToIndex(userIdToIndex);
		seq.setTopicsAssignments(topicAssignments);

		if (store)
			IOManager.writeObjectOnFile(seq, output);

		return seq;
	}

	/**
	 * Runs the burn-in period for the inferecen.
	 */
	protected void burnIn() {
		int iteration;
		double percent;
		double oldPercent;

		System.out.println("Starting burn-in.");
		oldPercent = 0;

		for (iteration = 0; iteration < burnIn; ++iteration) {
			percent = (double) iteration / burnIn;

			if (percent > oldPercent + 0.1) {
				System.out.println("Burn-in: " + padd(percent * 100, 1) + "%");
				oldPercent = percent;
			}

			gibbsLDA();

			if (updateHyperParams)
				updateAlpha(++updateAlphaIterations);
		}

		System.out.println("Burn-in: 100.0% complete");
	}

	/**
	 * Check if input parameters are valid.
	 * 
	 * @param output
	 *            Output file name.
	 */
	private void checkParameters() {
		System.out.println("Params");
		System.out.println("N_Topics\t" + nTopics);
		System.out.println("Alpha\t" + symmetricAlpha);
		System.out.println("Beta\t" + symmetricBeta);
		System.out.println("N_Max_Iterations\t" + maxIterations);
		System.out.println("Burn in\t" + burnIn);
		System.out.println("Sample Lag\t" + sampleLag);
		System.out.println("Update Alpha\t" + updateHyperParams);
		System.out.println("Output\t" + output);

		if (nTopics <= 0)
			throw new IllegalArgumentException(
					"The number of topics must be a non-negative integer.");

		if (symmetricAlpha <= 0)
			throw new IllegalArgumentException(
					"The symmetric Alpha parameter must be a non-negative real.");

		if (symmetricBeta <= 0)
			throw new IllegalArgumentException(
					"The symmetric Beta parameter must be a non-negative real.");

		if (maxIterations <= 0 || burnIn >= maxIterations)
			throw new IllegalArgumentException(
					"The maximum number of iteration"
							+ " must be a non-negative integer and greater"
							+ " than the burn-in's number of iteration.");

		if (burnIn <= 0)
			throw new IllegalArgumentException("The burn-in's number "
					+ "of iteration must be a non-negative integer.");

		if (sampleLag <= 0 || sampleLag >= maxIterations - burnIn)
			throw new IllegalArgumentException("The sample lag must be a "
					+ "non-negative integer and less than the"
					+ " difference between maxIterations and burnIn.");

		if (store)
			try {
				File f = new File(output);
				if (!f.exists())
					if (!f.createNewFile())
						throw new IllegalArgumentException(
								"Output file does not exist or invalid.");

			} catch (IOException e) {
				throw new IllegalArgumentException(
						"Output file does not exist or invalid.", e);
			}
	}

	/**
	 * Computes estimated topic-item associations.
	 */
	protected void computePhi(int sampleIteration) {
		int k1, k2; // Topic.
		int r; // Item.

		Integer tmpInteger;

		if (sampleIteration == 0)
			for (r = 0; r < nItems; ++r)
				for (k1 = 0; k1 < nTopics + 1; ++k1)
					for (k2 = 0; k2 < nTopics; ++k2) {
						tmpInteger = (Integer) n_k1_k2[r].get(k1, k2);

						phi[r][k1][k2] = tmpInteger == null ? symmetricBeta
								: tmpInteger + symmetricBeta;

						tmpInteger = (Integer) sum_n_k1_k2.get(k1, k2);
						phi[r][k1][k2] /= tmpInteger == null ? nItems
								* symmetricBeta : tmpInteger + nItems
								* symmetricBeta;
					}
		else {
			double newPhi;

			for (r = 0; r < nItems; ++r)
				for (k1 = 0; k1 < nTopics + 1; ++k1)
					for (k2 = 0; k2 < nTopics; ++k2) {
						tmpInteger = (Integer) n_k1_k2[r].get(k1, k2);

						newPhi = tmpInteger == null ? symmetricBeta
								: tmpInteger + symmetricBeta;

						tmpInteger = (Integer) sum_n_k1_k2.get(k1, k2);
						newPhi /= tmpInteger == null ? nItems * symmetricBeta
								: tmpInteger + nItems * symmetricBeta;

						sumPhi[r][k1][k2] += newPhi;

						phi[r][k1][k2] = sumPhi[r][k1][k2] / sampleIteration;
					}
		}
	}

	/*
	 * public double computeLogLikelihood() { int j; // User int s; // Item int
	 * item_prec;// Item int k_prec;// K prec
	 * 
	 * ArrayList<Action> observationForUser;
	 * 
	 * double observationProbability;
	 * 
	 * llk = 0d;
	 * 
	 * for (j = 0; j < nUsers; ++j) { observationForUser =
	 * data.getActionsForUser(userSet[j]);
	 * 
	 * item_prec = nItems; // epsilon for (Action po : observationForUser) { s =
	 * itemIdToIndex.get(po.getItemId()); k_prec = item_prec == nItems ? nTopics
	 * : (Short) topicAssignments.get(j, item_prec); observationProbability =
	 * 0d;
	 * 
	 * for (int k = 0; k < nTopics; ++k) //observationProbability += theta[j][k]
	 * * phi[s][k_prec][k]; ob
	 * 
	 * item_prec = s; llk += Math.log(observationProbability); } }
	 * 
	 * return llk; }
	 */
	/**
	 * Computes estimated user-topic associations.
	 */
	protected void computeTheta(int sampleIteration) {
		int j; // User.
		int k; // Topic.

		if (sampleIteration == 0)
			for (j = 0; j < nUsers; ++j)
				for (k = 0; k < nTopics; ++k)
					theta[j][k] = (n_kStar[j][k] + alpha[k])
							/ (counterOfItemsPerUserProfile[j] + alphaSum);
		else {
			double newTheta;

			for (j = 0; j < nUsers; ++j)
				for (k = 0; k < nTopics; ++k) {
					newTheta = (n_kStar[j][k] + alpha[k])
							/ (counterOfItemsPerUserProfile[j] + alphaSum);

					sumTheta[j][k] += newTheta;

					theta[j][k] = sumTheta[j][k] / sampleIteration;
				}
		}
	}

	/**
	 * Estimates the multinomial parameters (Theta, Phi) and the log-likelihood
	 * and perplexity of the model.
	 */
	protected void estimateMultinomialParametersAndStatistics(
			int sampleIteration) {
		computeTheta(sampleIteration);
		computePhi(sampleIteration);
		// llk = computeLogLikelihood();
		// perplexity = computePerplexity(llk);
	}

	public double[] getAlpha() {
		return alpha;
	}

	public SparseObjectMatrix2D[] getN_k1_k2() {
		return n_k1_k2;
	}

	public double[][][] getPhi() {
		return phi;
	}

	public SparseObjectMatrix2D getSum_n_k1_k2() {
		return sum_n_k1_k2;
	}

	public double getSymmetricBeta() {
		return symmetricBeta;
	}

	/**
	 * Runs the Gibbs sampling procedure for each topic assignment.
	 */
	protected void gibbsLDA() {

		// Cursors.
		short kMinus, k, kPlus; // Topics [K]
		int j; // User [M]
		int v, t; // Items [V]

		Action[] obsForUser;

		for (j = 0; j < nUsers; ++j) {
			obsForUser = data.getActionsForUser(userSet[j]);
			counterOfItemsPerUserProfile[j] = obsForUser.length;

			// The previous item of the first one is epsilon.
			kMinus = (short) nTopics;
			k = (short) nTopics;
			v = nItems;

			int listIndex = 0;
			for (Action po : obsForUser) {
				t = itemIdToIndex.get(po.getItemId());
				// kPlus = (Short) topicAssignments.get(j, t);
				kPlus = topicAssignments[j].get(listIndex);

				if (v != nItems) {
					k = sampleTopicViaFullConditionalProbability(j, v, t,
							kMinus, k, kPlus);
					// topicAssignments.set(j, v, Short.valueOf(k));
					topicAssignments[j].set(listIndex - 1, Short.valueOf(k));
				}

				kMinus = k;
				k = kPlus;
				v = t;
				++listIndex;
			}

			// Last topic
			t = (short) nItems;
			kPlus = (short) nTopics;

			k = sampleTopicViaFullConditionalProbability(j, v, t, kMinus, k,
					kPlus);
			// topicAssignments.set(j, v, Short.valueOf(k));
			topicAssignments[j].set(listIndex - 1, Short.valueOf(k));
		}
	}

	/**
	 * Initialized model parameters and counters, assigning a random (equally
	 * distributed) topic to each observation.
	 */
	@SuppressWarnings("unchecked")
	public void initializeModelParameters(PreferenceDataHandler preferenceData) {

		// Data information and indexes.
		data = preferenceData;

		nUsers = preferenceData.getNUsers();
		nItems = preferenceData.getNItems();

		userSet = toIntArray(preferenceData.getUserSet());

		userIdToIndex = preferenceData.getUserIndex();
		itemIdToIndex = preferenceData.getItemIndex();

		// Cursors.
		short k; // Topic [K]
		short kMinus; // Topic [K]
		int j; // User [M]
		int r; // Item [V]

		// Initialize count variables.
		n_kStar = new int[nUsers][nTopics];
		counterOfItemsPerUserProfile = new int[nUsers];

		n_k1_k2 = new SparseObjectMatrix2D[nItems];

		for (int i = 0; i < nItems; ++i)
			n_k1_k2[i] = new SparseObjectMatrix2D(nTopics + 1, nTopics); // epsilon
		sum_n_k1_k2 = new SparseObjectMatrix2D(nTopics + 1, nTopics); // epsilon

		// Topics are are initialised to values in [1,K] to determine the
		// initial state of the Markov chain.
		// topicAssignments = new SparseObjectMatrix2D(nUsers, nItems);
		topicAssignments = new LinkedList[nUsers];

		Integer tmp;
		Action[] obsForUser;

		// Update counters.
		for (j = 0; j < nUsers; ++j) {
			topicAssignments[j] = new LinkedList<Short>();
			obsForUser = data.getActionsForUser(userSet[j]);
			// Questa non va bene sicuro per i multipli -> a meno che il nome
			// non è fuorviante
			counterOfItemsPerUserProfile[j] = obsForUser.length + 1; // epsilon

			// The previous item of the first one is epsilon.
			kMinus = (short) nTopics;

			int listIndex = 0;
			for (Action po : obsForUser) {
				r = itemIdToIndex.get(po.getItemId());
				k = (short) rand.nextInt(nTopics);

				// topicAssignments.set(j, r, Short.valueOf(k));
				topicAssignments[j].add(listIndex, Short.valueOf(k));
				++n_kStar[j][k];

				tmp = (Integer) n_k1_k2[r].get(kMinus, k);
				n_k1_k2[r].set(kMinus, k, tmp == null ? Integer.valueOf(1)
						: Integer.valueOf(tmp + 1));

				tmp = (Integer) sum_n_k1_k2.get(kMinus, k);
				sum_n_k1_k2.set(kMinus, k, tmp == null ? Integer.valueOf(1)
						: Integer.valueOf(tmp + 1));

				kMinus = k;
				++listIndex;
			}
		}

		/*
		 * Initialize hyperparameters. ***
		 */

		// Initialize alpha.
		alpha = new double[nTopics];
		Arrays.fill(alpha, symmetricAlpha);
		alphaSum = nTopics * symmetricAlpha;

		// Each beta is equal to betaSymmetric.

		/*
		 * Initialize multinomial parameters. ***
		 */

		// Initialize theta.
		theta = new double[nUsers][nTopics];
		sumTheta = new double[nUsers][nTopics];

		// Initialize phi.
		phi = new double[nItems][nTopics + 1][nTopics];
		sumPhi = new double[nItems][nTopics + 1][nTopics];

		updateAlphaIterations = 1;
	}

	/**
	 * Initializes the parameters of the algorithm.
	 * 
	 * @param preferenceData
	 *            Training data handler.
	 * @param configFile
	 *            Configuration file.
	 * 
	 * @throws IOException
	 *             Thrown if the <code>configFile</code> is corrupted.
	 * @throws FileNotFoundException
	 *             Thrown if the <code>configFile</code> does not exist.
	 */
	protected String readConfigurationParameters(String configFile)
			throws IOException, FileNotFoundException {

		Properties properties = new Properties();
		properties.load(new FileInputStream(configFile));

		// nTopics = Integer.parseInt(properties.getProperty("n_topics"));
		symmetricAlpha = Double.parseDouble(properties.getProperty("alpha"));
		symmetricBeta = Double.parseDouble(properties.getProperty("beta"));
		maxIterations = Integer.parseInt(properties
				.getProperty("n_max_iterations"));
		burnIn = Integer.parseInt(properties.getProperty("burn_in"));
		sampleLag = Integer.parseInt(properties.getProperty("sample_lag"));
		rand = new Random(Long.parseLong(properties.getProperty("random_seed")));

		updateHyperParams = false;
		if (properties.getProperty("update_alpha").equalsIgnoreCase("true"))
			updateHyperParams = true;
		String s = properties.getProperty("n_max_iterations_alpha_update");
		if (s != null)
			maxAlphaUpdateIterations = Integer.parseInt(s);

		// thi output = properties.getProperty("output");

		checkParameters();

		return output;
	}

	/**
	 * Main method: Select initial state. Repeat a large number of times:
	 * 1.Select an element 2. Update conditional on other elements. If
	 * appropriate, output summary for each run.
	 * 
	 * @param preferenceData
	 *            Training data handler.
	 * @param configFile
	 *            Configuration file.
	 * @throws Exception
	 */
	public TokenBiTopicModel runInference(PreferenceDataHandler preferenceData,
			String configFile) throws Exception {

		// Read configuration parameters.
		String outputFileName = readConfigurationParameters(configFile);

		// Start chronometer.
		long initialTime = System.currentTimeMillis();

		// Initial parameters and counters of the model.
		initializeModelParameters(preferenceData);
		estimateMultinomialParametersAndStatistics(0);
		System.out.println("After initialization log-likelihood: " + llk);
		System.out.println("After initialization perplexity: " + perplexity);

		// Burn-in period.
		burnIn();

		// Sampling.
		boolean areMultinomialParamtersUpToDate = sampling();

		if (!areMultinomialParamtersUpToDate) {
			estimateMultinomialParametersAndStatistics(++sampleLagIterations);
			System.out.println("After burn-in log-likelihood: " + llk);
			System.out.println("After burn-in perplexity: " + perplexity);
		}

		System.out.println("Learning Time \t"
				+ (System.currentTimeMillis() - initialTime));

		return buildModel(outputFileName);
	}

	/**
	 * Sample the new topic of an item pair for the a user, computing the new
	 * topic's probability given the others topics and items.
	 * 
	 * @param j
	 *            User.
	 * @param v
	 *            Current item.
	 * @param t
	 *            Next item.
	 * @param kStar
	 *            Topic currently assigned to
	 * @param kMeno
	 *            Topic currently assigned to sPrec <code>s</code> in profile of
	 *            <code>j</code>.
	 * @return The new topic assigned to the input item pair and user.
	 */
	protected short sampleTopicViaFullConditionalProbability(int j, int v,
			int t, short kMinus, short kStar, short kPlus) {

		short k; // generic topic
		double[] p; // topic probability distribution

		double n1; // first part of the numerator of the likelihood formula
		double n2; // second part of the numerator of the likelihood formula
		double n3; // third part of the numerator of the likelihood formula

		double d1; // first part of the denominator of the likelihood formula
		double d2; // second part of the denominator of the likelihood formula

		Integer tempInteger; // temporary variable

		// Decrementing counters.
		--n_kStar[j][kStar];

		n_k1_k2[v].set(kMinus, kStar,
				(Integer) n_k1_k2[v].get(kMinus, kStar) - 1);

		sum_n_k1_k2.set(kMinus, kStar,
				(Integer) sum_n_k1_k2.get(kMinus, kStar) - 1);

		if (kPlus != nTopics) {
			n_k1_k2[t].set(kStar, kPlus,
					(Integer) n_k1_k2[t].get(kStar, kPlus) - 1);

			sum_n_k1_k2.set(kStar, kPlus, (Integer) sum_n_k1_k2.get(kStar,
					kPlus) - 1);
		}

		/*
		 * Compute p(z_mn). ***
		 */

		// Quasi probability distribution.
		p = new double[nTopics];

		for (k = 0; k < nTopics; ++k) {

			// Compute n1.
			n1 = n_kStar[j][k] + alpha[k];

			// Compute n2.
			tempInteger = (Integer) n_k1_k2[v].get(kMinus, k);

			if (tempInteger == null)
				tempInteger = 0;

			n2 = tempInteger + symmetricBeta;

			// Compute d1.
			tempInteger = (Integer) sum_n_k1_k2.get(kMinus, k);

			if (tempInteger == null)
				tempInteger = 0;

			d1 = tempInteger + nItems * symmetricBeta;

			// Compute n3, d2.
			if (kPlus == nTopics) {
				n3 = 1;
				d2 = 1;
			} else {

				// Compute n3.
				tempInteger = (Integer) n_k1_k2[t].get(kStar, k);

				if (tempInteger == null)
					tempInteger = 0;

				n3 = tempInteger + symmetricBeta;

				// Compute d2.
				tempInteger = (Integer) sum_n_k1_k2.get(kStar, k);

				if (tempInteger == null)
					tempInteger = 0;

				d2 = tempInteger + nItems * symmetricBeta;
			}

			// Compute p[k].
			p[k] = n1 * n2 * n3 / (d1 * d2);
		}

		/*
		 * Sample the newTopic. ***
		 */

		for (k = 1; k < p.length; ++k)
			p[k] += p[k - 1];

		// Scaled sample because of unnormalised p[].
		double cumulative = rand.nextDouble() * p[nTopics - 1];

		for (kStar = 0; kStar < p.length; ++kStar)
			if (cumulative < p[kStar])
				break;

		// Incrementing counters.
		++n_kStar[j][kStar];

		tempInteger = (Integer) sum_n_k1_k2.get(kMinus, kStar);
		sum_n_k1_k2.set(kMinus, kStar, tempInteger == null ? Integer.valueOf(1)
				: Integer.valueOf(tempInteger + 1));

		tempInteger = (Integer) n_k1_k2[v].get(kMinus, kStar);
		n_k1_k2[v].set(kMinus, kStar, tempInteger == null ? Integer.valueOf(1)
				: Integer.valueOf(tempInteger + 1));

		if (kPlus != nTopics) {
			tempInteger = (Integer) sum_n_k1_k2.get(kStar, kPlus);
			sum_n_k1_k2.set(kStar, kPlus, tempInteger == null ? Integer
					.valueOf(1) : Integer.valueOf(tempInteger + 1));

			tempInteger = (Integer) n_k1_k2[t].get(kStar, kPlus);
			n_k1_k2[t].set(kStar, kPlus, tempInteger == null ? Integer
					.valueOf(1) : Integer.valueOf(tempInteger + 1));
		}

		/*
		 * return the best topic for the observation **
		 */
		return kStar;
	}

	/**
	 * Runs the sampling procedure after the burn-in period.
	 * 
	 * @return A boolean that indicates if the multinomial parameters are up to
	 *         date.
	 */
	protected boolean sampling() {
		boolean converged = false;
		int iteration;
		int limit = maxIterations - burnIn;

		estimateMultinomialParametersAndStatistics(0);
		System.out.println("After burn-in log-likelihood: " + llk);
		System.out.println("After burn-in perplexity: " + perplexity);

		double percent;
		double oldPercent;

		System.out.println("Starting sampling.");
		oldPercent = 0;
		sampleLagIterations = 0;

		for (iteration = 0; !converged && iteration < limit; ++iteration) {
			percent = (double) iteration / limit;

			if (percent > oldPercent + 0.1)
				oldPercent = percent;

			gibbsLDA();

			if (updateHyperParams)
				updateAlpha(++updateAlphaIterations);

			if ((iteration + 1) % sampleLag == 0) {
				System.out.println("Iteration " + iteration);
				estimateMultinomialParametersAndStatistics(++sampleLagIterations);
			}
		}

		System.out.println("Sampling: 100.0% complete");

		return limit == 0 || converged || iteration % sampleLag == 0;
	}

	public void setnTopics(int nTopics) {
		this.nTopics = nTopics;
	}

	protected double sumGamma(int u, int[] observationForUser) {
		int i, k, h;
		double[] gamma = new double[nTopics];
		double[] newGamma = new double[nTopics];
		double ret;

		for (k = 0; k < nTopics; ++k)
			gamma[k] = phi[observationForUser[0]][nTopics][k];

		for (i = 1; i < observationForUser.length; ++i) {
			for (k = 0; k < nTopics; ++k) {
				newGamma[k] = 0;

				for (h = 0; h < nTopics; ++h)
					newGamma[k] += gamma[h] * theta[u][h]
							* phi[observationForUser[i]][h][k];
			}

			System.arraycopy(newGamma, 0, gamma, 0, nTopics);
		}

		ret = 0;

		for (k = 0; k < nTopics; ++k)
			ret += gamma[k] * theta[u][k];

		return ret;
	}

	private void updateAlpha(int updateAlphaIterations) {
		double previousAlpha[] = null;

		int n = 0;
		double num, den, newAlpha;

		do {
			if (n > maxAlphaUpdateIterations)
				break;

			previousAlpha = Arrays.copyOf(alpha, nTopics);

			den = 0;

			for (int u = 0; u < nUsers; u++)
				for (int j = 0; j < counterOfItemsPerUserProfile[u]; ++j)
					den += 1.0 / (j + alphaSum);

			for (int z = 0; z < nTopics; z++) {
				num = 0;

				for (int u = 0; u < nUsers; u++)
					for (int j = 0; j < n_kStar[u][z]; ++j)
						num += 1.0 / (j + alpha[z]);

				newAlpha = Math.exp(Math.log(alpha[z]) + Math.log(num)
						- Math.log(den));

				if (Double.isNaN(newAlpha) || Double.isInfinite(newAlpha)
						|| newAlpha < 0)
					newAlpha = 0;

				newAlpha = (alpha[z] * (updateAlphaIterations - 1) + newAlpha)
						/ updateAlphaIterations;

				alphaSum -= alpha[z];
				alpha[z] = newAlpha;
				alphaSum += alpha[z];
			}

			++n;
		} while (!ArrayUtilities.arrayConverged(alpha, previousAlpha, Math.pow(
				10, -4)));
	}
}