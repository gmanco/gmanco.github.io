/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package ranker;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import model.TokenBigramModel;

public class TokenBigramRanker {

	private int nTopics;
	private double theta[][];
	private double phi[][][];
	private Int2IntOpenHashMap userIdToIndex;
	private Int2IntOpenHashMap itemIdToIndex;

	public TokenBigramRanker(TokenBigramModel seqModel) {
		nTopics = seqModel.getnTopics();
		theta = seqModel.getTheta();
		phi = seqModel.getPhi();
		userIdToIndex = seqModel.getUserIdToIndex();
		itemIdToIndex = seqModel.getItemIdToIndex();
	}

	public double[] getRanks(int userId, int[] unrankedItemIds, int prevItemId) {
		double ranks[] = new double[unrankedItemIds.length];
		Integer userIndex = userIdToIndex.get(userId);

		int iPrec = itemIdToIndex.get(prevItemId);

		if (userIndex != null)
			for (int i = 0; i < unrankedItemIds.length; i++) {
				int itemIndex = itemIdToIndex.get(unrankedItemIds[i]);

				for (int k = 0; k < nTopics; k++)
					ranks[i] += phi[k][iPrec][itemIndex] * theta[userIndex][k];
			}

		return ranks;
	}
}