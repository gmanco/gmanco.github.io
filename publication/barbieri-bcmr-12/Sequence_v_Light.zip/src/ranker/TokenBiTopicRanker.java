/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package ranker;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.util.Iterator;
import java.util.LinkedList;

import model.TokenBiTopicModel;

public class TokenBiTopicRanker {

	private int nTopics;
	private double theta[][];
	private double phi[][][];
	private Int2IntOpenHashMap userIdToIndex;
	private Int2IntOpenHashMap itemIdToIndex;

	public TokenBiTopicRanker(TokenBiTopicModel seqModel) {
		nTopics = seqModel.getnTopics();
		theta = seqModel.getTheta();
		phi = seqModel.getPhi();
		userIdToIndex = seqModel.getUserIdToIndex();
		itemIdToIndex = seqModel.getItemIdToIndex();
	}

	public double[] getRanks(int userId, int[] unrankedItemIds,
			LinkedList<Integer> prevItemIds) {

		double ranks[] = new double[unrankedItemIds.length];
		Integer u = userIdToIndex.get(userId);

		if (u != null) {
			int i, h, k, itemIndex, toEvaluateItem;
			double[][] gamma = new double[prevItemIds.size()][nTopics];
			double[][] tmpRes = new double[unrankedItemIds.length][nTopics];

			Iterator<Integer> it = prevItemIds.iterator();
			i = 0;

			if (it.hasNext()) {
				itemIndex = itemIdToIndex.get(it.next());

				for (k = 0; k < nTopics; k++)
					gamma[0][k] = phi[itemIndex][nTopics][k];

				i = 1;
				while (it.hasNext()) {
					int tmp = it.next();
					/*
					 * if(!itemIdToIndex.containsKey(tmp)){
					 * System.out.println("chiave "+tmp+" non presente"); }
					 */
					itemIndex = itemIdToIndex.get(tmp);

					for (k = 0; k < nTopics; k++)
						for (h = 0; h < nTopics; h++)
							gamma[i][k] += gamma[i - 1][h] * theta[u][h]
									* phi[itemIndex][h][k];

					++i;
				}
			}

			double sum;

			for (toEvaluateItem = 0; toEvaluateItem < unrankedItemIds.length; ++toEvaluateItem) {
				itemIndex = itemIdToIndex.get(unrankedItemIds[toEvaluateItem]);

				for (k = 0; k < nTopics; k++) {
					sum = 0;

					if (i > 0)
						for (h = 0; h < nTopics; h++)
							sum += gamma[i - 1][h] * theta[u][h]
									* phi[itemIndex][h][k];

					tmpRes[toEvaluateItem][k] = i == 0 ? phi[itemIndex][nTopics][k]
							: sum;
				}
			}

			for (toEvaluateItem = 0; toEvaluateItem < unrankedItemIds.length; ++toEvaluateItem)
				for (k = 0; k < nTopics; k++)
					ranks[toEvaluateItem] += tmpRes[toEvaluateItem][k]
							* theta[u][k];
		}

		return ranks;
	}
}