/* 
 * This file is part of Sequence_v_light.
 * 
 * Sequence_v_light is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3 of the License.
 * 
 * Sequence_v_light is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package ranker;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;

import java.util.Iterator;
import java.util.LinkedList;

import model.TopicBigramModel;

/**
 * 
 * @author Ettore Ritacco
 * @version 2.0.1
 */
public class TopicBigramRanker {

	private int nTopics;
	private double theta[][][];
	private double phi[][];
	private Int2IntOpenHashMap userIdToIndex;
	private Int2IntOpenHashMap itemIdToIndex;

	public TopicBigramRanker(int N, TopicBigramModel seqModel) {
		nTopics = seqModel.getnTopics();
		theta = seqModel.getTheta();
		phi = seqModel.getPhi();
		userIdToIndex = seqModel.getUserIdToIndex();
		itemIdToIndex = seqModel.getItemIdToIndex();
	}

	public double[] getRanks(int userId, int[] itemSet,
			LinkedList<Integer> prevItemIds) {

		double ranks[] = new double[itemSet.length];
		Integer u = userIdToIndex.get(userId);

		int i, h, k, itemIndex, toEvaluateItem;
		double[][] gamma = new double[prevItemIds.size()][nTopics];
		double[][] tmpRes = new double[itemSet.length][nTopics];
		double sum;

		Iterator<Integer> it = prevItemIds.iterator();
		i = 0;

		if (it.hasNext()) {
			itemIndex = itemIdToIndex.get(it.next());

			for (k = 0; k < nTopics; k++)
				gamma[0][k] = phi[k][itemIndex];

			i = 1;
			while (it.hasNext()) {
				Integer tmp = it.next();
				if (tmp == null || !itemIdToIndex.containsKey(tmp)) {
					System.out.println(" TMP: " + tmp + " da' errore ");
					if (tmp != null && !itemIdToIndex.containsKey(tmp))
						System.out.println("NON esiste la chiave");
					continue;
				}
				itemIndex = itemIdToIndex.get(tmp);

				for (k = 0; k < nTopics; k++) {
					sum = 0;

					for (h = 0; h < nTopics; h++)
						sum += gamma[i - 1][h] * theta[u][h][k];

					gamma[i][k] = phi[k][itemIndex] * sum;
				}

				++i;
			}
		}

		for (toEvaluateItem = 0; toEvaluateItem < itemSet.length; ++toEvaluateItem) {
			itemIndex = itemIdToIndex.get(itemSet[toEvaluateItem]);

			for (k = 0; k < nTopics; k++) {
				sum = 0;

				if (i > 0)
					for (h = 0; h < nTopics; h++)
						sum += gamma[i - 1][h] * theta[u][h][k];

				tmpRes[toEvaluateItem][k] = i == 0 ? phi[k][itemIndex]
						: phi[k][itemIndex] * sum;
			}

		}

		for (toEvaluateItem = 0; toEvaluateItem < itemSet.length; ++toEvaluateItem)
			for (k = 0; k < nTopics; k++)
				ranks[toEvaluateItem] += tmpRes[toEvaluateItem][k];

		return ranks;
	}
}